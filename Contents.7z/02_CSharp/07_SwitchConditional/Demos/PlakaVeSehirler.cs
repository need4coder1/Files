﻿namespace _07_SwitchConditional.Demos
{
    public class PlakaVeSehirler
    {
        public static void Calistir()
        {
            // Girilen plaka koduna göre şehir adını getiren program.
            Console.Write("Lütfen plaka kodu girin: ");
            int plaka = int.Parse(Console.ReadLine());
            string sonuc;

            //if (plaka == 6)
            //{
            //    sonuc = "Ankara";
            //}
            //else if (plaka == 34)
            //{
            //    sonuc = "İstanbul";
            //}
            //else if (plaka == 35)
            //{
            //    sonuc = "İzmir";
            //}
            //else if (plaka == 26)
            //{
            //    sonuc = "Eskişehir";
            //}
            //else
            //{
            //    sonuc = "Girdiğiniz plaka sistemde bulunamadı.";
            //}
            switch (plaka)
            {
                case 6:
                    sonuc = "Ankara";
                    break;
                case 34:
                    sonuc = "İstanbul";
                    break;
                case 35:
                    sonuc = "İzmir";
                    break;
                case 26:
                    sonuc = "Eskişehir";
                    break;
                default:
                    sonuc = "Girdiğiniz plaka sistemde bulunamadı.";
                    break;
            }

            Console.WriteLine("Girdiğiniz plaka kodu: " + plaka + ", plaka kodunun şehri: " + sonuc);
        }
    }
}
