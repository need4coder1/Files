﻿namespace _16_Math.Demos
{
    public class TekSayiyaVeCiftSayiyaGoreRound
    {
        public static void Calistir()
        {
            Console.WriteLine();

            // 5 ondalık hanesine göre çift sayıların aşağı tek sayıların yukarı yuvarlanması:
            for (decimal sayi = 1.0m; sayi <= 1.9m; sayi += 0.1m)
            {
                if (sayi == 1.5m)
                    Console.WriteLine("Yuvarlanan tek sayı (1,5): " + sayi + "; yuvarlama sonucu: " + Math.Round(sayi));
                else
                    Console.WriteLine("Yuvarlanan tek sayı (1): " + sayi + "; yuvarlama sonucu: " + Math.Round(sayi));
            }

            for (decimal sayi = 2.0m; sayi <= 2.9m; sayi += 0.1m)
            {
                if (sayi == 2.5m)
                    Console.WriteLine("Yuvarlanan çift sayı (2,5): " + sayi + "; yuvarlama sonucu: " + Math.Round(sayi));
                else
                    Console.WriteLine("Yuvarlanan çift sayı (2): " + sayi + "; yuvarlama sonucu: " + Math.Round(sayi));
            }
        }
    }
}
