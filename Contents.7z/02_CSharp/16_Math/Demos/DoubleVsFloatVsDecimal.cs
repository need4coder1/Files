﻿namespace _16_Math.Demos
{
    public class DoubleVsFloatVsDecimal
    {
        public static void Calistir()
        {
            Console.WriteLine();

            // double (double precision: çift ondalık duyarlık), float (single precision: tek ondalık duyarlık)

            double doubleNo1 = 1.1;
            double doubleNo2 = doubleNo1 + 0.1;
            Console.WriteLine("double no1: " + doubleNo1 + "; double no2: " + doubleNo2);
            // konsola "double no1: 1,1; double no2: 1,2000000000000002" yazdırır

            if (doubleNo2 == 1.2)
                Console.WriteLine("double no2 eşittir 1,2");
            else
                Console.WriteLine("double no2 eşit değildir 1,2");
            // konsola "double no2 eşit değildir 1,2" yazdırır



            float floatNo1 = 1.1f;
            float floatNo2 = floatNo1 + 0.1f;
            Console.WriteLine("float no1: " + floatNo1 + "; float no2: " + floatNo2);
            // konsola "float no1: 1,1; float no2: 1,2" yazdırır

            if (floatNo2 == 1.2f)
                Console.WriteLine("float no2 eşittir 1,2");
            else
                Console.WriteLine("float no2 eşit değildir 1,2");
            // konsola "float no2 eşittir 1,2" yazdırır



            decimal decimalNo1 = 1.1m;
            decimal decimalNo2 = decimalNo1 + 0.1m;
            Console.WriteLine("decimal no1: " + decimalNo1 + "; decimal no2: " + decimalNo2);
            // konsola "decimal no1: 1,1; decimal no2: 1,2" yazdırır

            if (decimalNo2 == 1.2m)
                Console.WriteLine("decimal no2 eşittir 1,2");
            else
                Console.WriteLine("decimal no2 eşit değildir 1,2");
            // konsola "decimal no2 eşittir 1,2" yazdırır
        }
    }
}
