﻿namespace _14_String.Demos
{
    public class MulakatSorusu2
    {
        public static void Calistir()
        {
            // Bir metin içerisinde tek haneli sayılara kadar olan metinsel verileri parça parça yazdırma
            // ve en uzun parçayı bulup yazdırma:
            // Örnek veri: Çağıl1Alsaç2Ankara3Türkiye
            Console.Write("Metin giriniz: ");
            string metin = Console.ReadLine();
           


            // 1. yöntem:
            //string[] metinParcalari = metin.Split(new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' });
            // 2. yöntem:
            //string[] metinParcalari = metin.Split('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
            // 3. yöntem:
            char[] ayraclar = new char[10];
            for (int i = 0; i <= 9; i++)
            {
                ayraclar[i] = i.ToString()[0];
            }
            string[] metinParcalari = metin.Split(ayraclar);



            Console.WriteLine("Metin parçaları:");
            foreach (string metinParcasi in metinParcalari)
            {
                Console.WriteLine(metinParcasi);
            }
            Console.WriteLine("En uzun parça:");
            int enUzunMetinParcasiIndexi = 0;
            int enUzunMetinParcasiUzunlugu = metinParcalari[enUzunMetinParcasiIndexi].Length;
            for (int i = 1; i < metinParcalari.Length; i++)
            {
                if (metinParcalari[i].Length > enUzunMetinParcasiUzunlugu)
                {
                    enUzunMetinParcasiUzunlugu = metinParcalari[i].Length;
                    enUzunMetinParcasiIndexi = i;
                }
            }
            Console.WriteLine(metinParcalari[enUzunMetinParcasiIndexi] + " (" + enUzunMetinParcasiUzunlugu + " karakter)");
        }
    }
}
