﻿namespace _10_WhileLoop.Demos
{
    public class AritmetikOrtalama
    {
        public static void Calistir()
        {
            Console.WriteLine("Pozitif sayıların aritmetik ortalaması hesaplaması:");
            int l = 0; // Kaç sayı girildiği
            double sayilarinToplami = 0;
            double sayi;
            Console.Write((l + 1) + ". sayıyı girin (-1 = Çıkış): ");
            sayi = Convert.ToDouble(Console.ReadLine());
            while (sayi != -1)
            {
                sayilarinToplami += sayi;
                l++;
                Console.Write((l + 1) + ". sayıyı girin (-1 = Çıkış): ");
                sayi = Convert.ToDouble(Console.ReadLine());
            }
            if (l > 0)
                Console.WriteLine("Aritmetik ortalama: " + sayilarinToplami / l);
            else
                Console.WriteLine("Herhangi bir sayı girmediniz.");
        }
    }
}
