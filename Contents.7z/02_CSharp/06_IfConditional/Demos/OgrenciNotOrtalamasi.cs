﻿namespace _06_IfConditional.Demos
{
    public class OgrenciNotOrtalamasi
    {
        public static void Calistir()
        {
            /* Algoritma:
            1- başla
            2- öğrenci adı gir
            3- öğrenci adı boş değil ise 4, boş ise 13. adıma git
            4- vize1 gir
            5- eğer vize1 0 ile 100 aralığında ise 6, değil ise 14. adıma git
            6- vize2 gir
            7- eğer vize2 0 ile 100 aralığında ise 8, değil ise 15. adıma git
            8- final gir
            9- eğer final 0 ile 100 aralığında ise 10, değil ise 16. adıma git
            10- ortalama = (vize1 + vize2) * 0.2 + final * 0.6 hesabını yap
            11- eğer ortalama < 60 ise ortalama ve öğrenci adı ile birlikte kaldı yazdır ve 17. adıma git
            12- eğer ortalama >= 60 ise ortalama ve öğrenci adı ile birlikte geçti yazdır ve 17. adıma git
            13- öğrenci adı boş girilemez yadır ve 17. adıma git
            14- vize1 0 ile 100 aralığında olmalıdır yazdır ve 17. adıma git
            15- vize2 0 ile 100 aralığında olmalıdır yazdır ve 17. adıma git
            16- final 0 ile 100 aralığında olmalıdır yazdır ve 17. adıma git
            17- bitir
            */

            string ogrenciAdi;
            double vize1;
            double vize2;
            double final;
            double ortalama;
            const double vizeCarpan = 0.2; // constant (sabit)
            const double finalCarpan = 0.6; // constant (sabit)
            //vizeCarpan = 0.1; // hata verecektir sabit olduğu için, sabitler değiştirilemez

            Console.Write("Öğrenci adı: ");
            ogrenciAdi = Console.ReadLine();

            if (ogrenciAdi != "")
            {
                Console.Write("1. Vize: ");
                vize1 = Convert.ToDouble(Console.ReadLine());

                if (vize1 >= 0 && vize1 <= 100)
                {
                    Console.Write("2. Vize: ");
                    vize2 = double.Parse(Console.ReadLine());

                    if (!(vize2 >= 0 && vize2 <= 100))
                    {
                        Console.WriteLine("2. Vize 0 (dahil) ile 100 (dahil) aralığında olmalıdır!");
                    }
                    else
                    {
                        Console.Write("Final: ");
                        final = double.Parse(Console.ReadLine());

                        if (final < 0 || final > 100)
                        {
                            Console.WriteLine("Final 0 (dahil) ile 100 (dahil) aralığında olmalıdır!");
                        }
                        else
                        {
                            //ortalama = (vize1 + vize2) * 0.2 + final * 0.6;
                            ortalama = (vize1 + vize2) * vizeCarpan + final * finalCarpan;
                            if (ortalama >= 60)
                                Console.WriteLine(ogrenciAdi + " ortalaması: " + ortalama + " - Geçti!");
                            else
                                Console.WriteLine("{0} ortalaması: " + ortalama + " - Kaldı!", ogrenciAdi);
                        }
                    }
                }
                else
                {
                    Console.WriteLine("1. Vize 0 (dahil) ile 100 (dahil) aralığında olmalıdır!");
                }
            }
            else
            {
                Console.WriteLine("Öğrenci adı boş girilemez!");
            }
        }
    }
}
