﻿namespace _09_ForLoop.Demos
{
    public class Faktoriyel
    {
        public static void Calistir()
        {
            int sayi;
            int sonuc = 1;
            Console.Write("Bir sayı girin: ");
            sayi = Int32.Parse(Console.ReadLine());

            // 1. yöntem:
            //for (int i = 2; i <= sayi; i++)
            //{
            //    sonuc *= i; // sonuc = sonuc * i;
            //}
            // 2. yöntem:
            for (int i = sayi; i >= 2; i--)
            {
                sonuc *= i; // sonuc = sonuc * i;
            }

            Console.WriteLine(sayi + " sayısının faktöriyeli: " + sonuc);
        }
    }
}