﻿create nonclustered index idx_filmgise
on Film (gisesi)