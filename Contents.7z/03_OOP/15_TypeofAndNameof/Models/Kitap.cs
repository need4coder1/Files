﻿namespace _15_TypeofAndNameof.Models
{
    /// <summary>
    /// Kitap bilgilerini yöneteceğimiz somut model sınıfı.
    /// </summary>
    class Kitap
    {
        #region Properties
        public string ISBN { get; set; }
        public string Yazari { get; set; }
        public string Adi { get; set; }
        public short Yili { get; set; }
        #endregion

        #region Constructors
        public Kitap(string isbn, string yazari, string adi, short yili)
        {
            ISBN = isbn;
            Yazari = yazari;
            Adi = adi;
            Yili = yili;
        }
        #endregion

        #region Behaviors
        public override string ToString() // Object (object) class'ından miras alınan ToString methodunu ezerek kendi oluşturduğumuz string'i dönüyoruz
        {
            return "ISBN: " + ISBN + "\nAdı: " + Adi + "\nYazarı: " + Yazari + "\nYılı: " + Yili;
        }
        #endregion
    }
}
