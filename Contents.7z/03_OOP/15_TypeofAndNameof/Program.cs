﻿using _15_TypeofAndNameof.Models;

namespace _15_TypeofAndNameof
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Kitap kitap = new Kitap("9789753638029", "Sabahattin Ali", "Kürk Mantolu Madonna", 1998); // object initialization

            // eğer Kitap class'ında ToString methodunu override etmemiş olsaydık objenin namespace'i ile birlikte tipi dönecekti ve
            // konsola _15_TypeofAndNameof.Models.Kitap yazdıracaktı
            Console.WriteLine("Kitap:\n" + kitap); // Console.WriteLine(kitap.ToString()); de yazılabilir

            Console.WriteLine("\nnameof: " + nameof(Kitap)); // nameof parametre olarak kullanılan class'ın adını döner

            Console.WriteLine("\ntypeof: " + typeof(Kitap)); // typeof parametre olarak kullanılan class'ın namespace'i ile birlikte tipini döner

            Console.WriteLine("\nType: " + kitap.GetType()); // GetType methodu kullanıldığı obje üzerinden namespace'i ile birlikte tipi döner

            if (kitap.GetType() == typeof(Kitap)) // if (kitap is Kitap) da yazılabilir
                                                  // eğer kitap objesinin tipi Kitap ise ki öyle olduğu için if koşulu içi konsola yazdırılacak
                Console.WriteLine("\nkitap değişkeni Kitap tipinde bir objeye refere eder.");
            else // eğer kitap objesinin tipi Kitap değilse
                Console.WriteLine("\nkitap değişkeni Kitap tipinde bir objeye refere etmez.");
        }
    }
}