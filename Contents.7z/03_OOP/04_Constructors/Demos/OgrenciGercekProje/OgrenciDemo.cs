﻿namespace _04_Constructors.Demos.OgrenciGercekProje
{
    public class OgrenciDemo
    {
        public static void Calistir()
        {
            Ogrenci ogrenci1 = new Ogrenci()
            {
                Adi = "Çağıl",
                Soyadi = "Alsaç",
                Vize1 = 10,
                Vize2 = 20.5m,
                Final = 60
            };

            Console.WriteLine($"\nÖğrenci:\n" +
                $"Adı Soyadı: {ogrenci1.Adi} {ogrenci1.Soyadi}\n" +
                $"1. Vize: {ogrenci1.Vize1}\n" +
                $"2. Vize: {ogrenci1.Vize2}\n" +
                $"Final: {ogrenci1.Final}\n" +
                $"Ortalama: {ogrenci1.Ortalama}\n" +
                $"Durum: {ogrenci1.Durum}");



            Ogrenci ogrenci2 = new Ogrenci("Leo", "Alsaç", 90, 85.5m, 75);

            Console.WriteLine($"\nÖğrenci:\n" +
                $"Adı Soyadı: {ogrenci2.Adi} {ogrenci2.Soyadi}\n" +
                $"1. Vize: {ogrenci2.Vize1}\n" +
                $"2. Vize: {ogrenci2.Vize2}\n" +
                $"Final: {ogrenci2.Final}\n" +
                $"Ortalama: {ogrenci2.Ortalama}\n" +
                $"Durum: {ogrenci2.Durum}");
        }
    }
}
