﻿namespace _04_Constructors.Demos.OgrenciGercekProje
{
    public enum Durumlar
    {
        Geçti,
        Kaldı
    }
}
