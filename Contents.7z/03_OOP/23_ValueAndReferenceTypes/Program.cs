﻿using _23_ValueAndReferenceTypes.ReferenceTypes;
using _23_ValueAndReferenceTypes.ValueTypes;

namespace _23_ValueAndReferenceTypes
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // bool, byte, short, int, long, float, double, decimal, enum, char, DateTime (struct) ve TimeSpan (struct) değer (value) tiplere örnek verilebilir.
            // string, dizi (array), class, abstract class ve interface referans (reference) tiplere örnek verilebilir.

            #region Demos
            ValueTypesDemo valueTypesDemo = new ValueTypesDemo();
            valueTypesDemo.Calistir();

            Console.WriteLine();

            ReferenceTypesDemo1 referenceTypesDemo1 = new ReferenceTypesDemo1();
            referenceTypesDemo1.Calistir();

            Console.WriteLine();

            ReferenceTypesDemo2 referenceTypesDemo2 = new ReferenceTypesDemo2();
            referenceTypesDemo2.Calistir();

            Console.WriteLine();

            ReferenceTypesDemo3 referenceTypesDemo3 = new ReferenceTypesDemo3();
            referenceTypesDemo3.Calistir();

            Console.WriteLine();

            ReferenceTypesDemo4 referenceTypesDemo4 = new ReferenceTypesDemo4();
            referenceTypesDemo4.Calistir();
            #endregion
        }
    }
}