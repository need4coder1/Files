﻿namespace _23_ValueAndReferenceTypes.ReferenceTypes
{
    /// <summary>
    /// // Referans tiplerin methodlarda kullanımı.
    /// </summary>
    public class ReferenceTypesDemo3 
    {
        public void Calistir()
        {
            #region String
            string city1 = "Liberty City";
            Console.WriteLine("City 1: " + city1); // konsola "City 1: Liberty City" yazdırır
            Update(city1);
            Console.WriteLine("City 1: " + city1); // konsola "City 1: Liberty City" yazdırır
            #endregion



            #region Class
            City city2 = new City() { Name = "Los Santos" };
            Console.WriteLine("City 2: " + city2.Name); // konsola "City 2: Los Santos" yazdırır
            Update(city2);
            Console.WriteLine("City 2: " + city2.Name); // konsola "City 2: San Fierro" yazdırır
            #endregion
        }



        #region String için method
        private void Update(string city)
        {
            city = "Vice City"; // string referans tip olmasına rağmen atamalarda değer tip gibi davrandığından
                                // atama sonucu sadece bu method içerisinde geçerlidir ve dışarıya yansımaz
        }
        #endregion



        #region Class için method
        void Update(City city)
        {
            city.Name = "San Fierro"; // city referans parametresinin refere ettiği objenin Name özelliği
                                      // güncelleneceğinden atama sonucu hem bu method içerisinde geçerlidir
                                      // hem de dışarıya yansır
        }
        #endregion
    }



    #region Class
    class City
    {
        public string Name { get; set; }
    }
    #endregion
}
