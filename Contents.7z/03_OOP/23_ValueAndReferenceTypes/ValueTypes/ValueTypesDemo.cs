﻿namespace _23_ValueAndReferenceTypes.ValueTypes
{
    public class ValueTypesDemo
    {
        public void Calistir()
        {
            #region Value Types Demo 1
            int sayi1 = 10; // atama (assignment veya set) değer üzerinden gerçekleşir, sayi1'in değeri 10 olur
            int sayi2 = 20; // sayi2'nin değeri 20 olur
            sayi2 = sayi1; // sayi2'nin değeri 10 olur
            sayi1 = 100; // sayi1'in değeri 100 olur
            Console.WriteLine($"Sayı 2: {sayi2}, Sayı 1: {sayi1}"); // konsola "Sayı 2: 10, Sayı 1: 100" yazdırır
            #endregion



            #region Value Types Demo 2
            int sayi3 = 30; // sayi3'ün değeri 30 olur
            Guncelle(sayi3);
            Console.WriteLine($"Sayı 3: {sayi3}"); // konsola "Sayı 3: 30" yazdırır
            #endregion
        }



        #region Value Types Demo 2 Methodu
        void Guncelle(int sayi)
        {
            sayi = 300; // sayi int değer tipinde olduğundan atanması sadece bu method için geçerli olur, method dışına yansımaz
        }
        #endregion
    }
}
