﻿namespace _25_HasArelationship._1_GokCisimleri.Entities
{
    public enum GokCismiTipi
    {
        Tumu = 1,
        Yildiz,
        Gezegen,
        Uydu
    }
}
