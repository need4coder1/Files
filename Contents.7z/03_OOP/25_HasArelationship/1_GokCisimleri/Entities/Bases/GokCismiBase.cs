﻿namespace _25_HasArelationship._1_GokCisimleri.Entities.Bases
{
    /// <summary>
    /// Yildiz, Gezegen ve Uydu sınıflarının miras aldığı soyut base sınıf.
    /// </summary>
    public abstract class GokCismiBase
    {
        public string Adi { get; set; }
        public double YariCapi { get; set; }
        public decimal KendiEtrafindaDonmeHizi { get; set; }
    }
}
