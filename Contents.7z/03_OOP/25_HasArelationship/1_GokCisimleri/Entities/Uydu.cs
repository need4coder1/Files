﻿using _25_HasArelationship._1_GokCisimleri.Entities.Bases;

namespace _25_HasArelationship._1_GokCisimleri.Entities
{
    /// <summary>
    /// GokCismiBase soyut sınıfından miras alan somut sınıf.
    /// </summary>
    public class Uydu : GokCismiBase // is-a relationship: Uydu bir GokCismiBase'dir
    {
        public Gezegen Gezegen { get; set; } // has-a relationship: bir Uydu objesi bir Gezegen objesine sahip olabilir
    }
}
