﻿using _25_HasArelationship._1_GokCisimleri;
using _25_HasArelationship._2_BankaHesaplari;

namespace _25_HasArelationship
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Gök Cisimleri
            GokCisimleriDemo gokCisimleriDemo = new GokCisimleriDemo();
            gokCisimleriDemo.Calistir();
            #endregion

            Console.WriteLine();

            #region Banka Hesapları
            BankaHesaplariDemo bankaHesaplariDemo = new BankaHesaplariDemo();
            bankaHesaplariDemo.Calistir();
            #endregion
        }
    }
}