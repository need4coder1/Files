﻿namespace _25_HasArelationship._2_BankaHesaplari.Enums
{
    /// <summary>
    /// İşlem sonuçları için başarılı sonucu pozitif, hatalı sonuçları negatif değerler olarak tutan enum.
    /// </summary>
    public enum IslemSonucu
    {
        NegatifMiktar = -2,
        YetersizBakiye = -1,
        Basarili = 1
    }
}
