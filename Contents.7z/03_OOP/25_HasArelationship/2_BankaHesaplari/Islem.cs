﻿using _25_HasArelationship._2_BankaHesaplari.Bases;

namespace _25_HasArelationship._2_BankaHesaplari
{
    /// <summary>
    /// İşlem base (parent) soyut sınıfından miras alan somut sınıf.
    /// </summary>
    public class Islem : IslemBase // is-a relationship: Islem bir IslemBase'dir
    {
        #region Constructor
        public Islem(decimal miktar, bool paraYatirmaMi) : base(miktar, paraYatirmaMi) // base (parent) sınıfın parametreli constructor'ı
                                                                                       // olduğu için bu sınıfta da base sınıfa
                                                                                       // parametreleri gönderebileceğimiz bir
                                                                                       // parametreli constructor oluşturuyoruz
        {
        }
        #endregion
    }
}
