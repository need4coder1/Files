﻿namespace _07_Interfaces.Models
{
    class Ogrenci : IKisi // öğrenci somut (concrete) sınıfı kişi interface'ini implemente edecek, bunun için ampüle tıklayıp
                                   // veya klavyedeki Ctrl ve . tuşlarına basıp implement interface'e tıklıyoruz,
                                   // Ogrenci bir IKisi'dir
    {
        // implement interface dedikten sonra interface içerisindeki özellik veya method tanımları üzerinden
        // otomatik olarak özellik ve methodlar sınıfımızda oluşturulur



        // property'lerin interface'teki tanımlara göre oluşturulması
        public string TcKimlikNo { get; set; }
        public string Adi { get; set; }
        public string Soyadi { get; set; }




        // eğer istenirse interface'teki tanımlar dışında ekstra özellik veya methodlar class içerisinde oluşturulabilir
        public string Okulu { get; set; }



        // behavior'ların (method) interface'teki tanımlara göre oluşturulması
        public string Getir()
        {
            return $"T.C. Kimlik No: {TcKimlikNo}\nÖğrenci: {Adi} {Soyadi}\nOkulu: {Okulu}";
        }
    }
}
