﻿using _07_Interfaces.Demos.Sekiller.Bases;

namespace _07_Interfaces.Demos.Sekiller
{
    /// <summary>
    /// IKoseliSekil interface'ini implemente eden class.
    /// </summary>
    class Dikdortgen : IKoseliSekil // Dikdortgen bir IKoseliSekil'dir şeklinde de okunabilir
    {
        public double Genislik { get; set; } // özellik implementasyonu
        public double Yukseklik { get; set; } // özellik implementasyonu

        public double AlanHesapla() // method implementasyonu
        {
            return Genislik * Yukseklik;
        }

        public double CevreHesapla() // method implementasyonu
        {
            return 2 * (Genislik + Yukseklik);
        }
    }
}
