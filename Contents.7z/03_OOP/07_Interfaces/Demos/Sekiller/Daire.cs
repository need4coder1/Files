﻿using _07_Interfaces.Demos.Sekiller.Bases;

namespace _07_Interfaces.Demos.Sekiller
{
    /// <summary>
    /// IYuvarlakSekil interface'ini implemente eden class.
    /// </summary>
    class Daire : IYuvarlakSekil // Daire bir IYuvarlakSekil'dir şeklinde de okunabilir
    {
        public double Yaricap { get; set; } // özellik implementasyonu
        public bool PiUcMu { get; set; } // özellik implementasyonu

        public double AlanHesapla() // method implementasyonu
        {
            return PiUcMu ? 3 * Math.Pow(Yaricap, 2) : Math.PI * Math.Pow(Yaricap, 2);
        }

        public double CevreHesapla() // method implementasyonu
        {
            return PiUcMu ? 2 * 3 * Yaricap : 2 * Math.PI * Yaricap;
        }
    }
}
