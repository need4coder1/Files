﻿using _07_Interfaces.Demos.Sekiller.Bases;

namespace _07_Interfaces.Demos.Sekiller
{
    public class SekillerDemo
    {
        public static void Calistir()
        {
            Daire daire1 = new Daire() // Daire tipinde instance (obje) oluşturma (initialization)
            {
                Yaricap = 5,
                PiUcMu = true
            };

            Console.WriteLine("1. dairenin çevresi: " + daire1.CevreHesapla());
            Console.WriteLine("1. dairenin alanı: " + daire1.AlanHesapla());



            Daire daire2 = new Daire()
            {
                Yaricap = 10
            }; // PiUcMu özelliği atanmadığından default (varsayılan) false atanacaktır

            Console.WriteLine($"2. dairenin çevresi: {daire2.CevreHesapla()}");
            Console.WriteLine($"2. dairenin alanı: {daire2.AlanHesapla()}");



            IKoseliSekil koseliSekil1 = new Dikdortgen() // IKoseliSekil tipindeki değişken Dikdortgen tipindeki objeyi refere ediyor
            {
                Genislik = 4,
                Yukseklik = 3
            };

            Console.WriteLine("1. dikdörtgenin çevresi: " + koseliSekil1.CevreHesapla());
            Console.WriteLine("1. dikdörtgenin alanı: " + koseliSekil1.AlanHesapla());



            IKoseliSekil koseliSekil2 = new Dikucgen() // IKoseliSekil tipindeki değişken Dikucgen tipindeki objeyi refere ediyor
            {
                Genislik = 8,
                Yukseklik = 6
            };

            Console.WriteLine("1. diküçgenin çevresi: " + koseliSekil2.CevreHesapla());
            Console.WriteLine("1. diküçgenin alanı: " + koseliSekil2.AlanHesapla());



            Dikucgen dikucgen = new Dikucgen() // Dikucgen tipindeki değişken Dikucgen tipindeki objeyi refere ediyor
            {
                Genislik = 12,
                Yukseklik = 9
            };

            Console.WriteLine("2. diküçgenin çevresi: " + dikucgen.CevreHesapla());
            Console.WriteLine("2. diküçgenin alanı: " + dikucgen.AlanHesapla());
        }
    }
}
