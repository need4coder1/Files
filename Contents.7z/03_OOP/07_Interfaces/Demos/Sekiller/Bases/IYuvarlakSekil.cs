﻿namespace _07_Interfaces.Demos.Sekiller.Bases
{
    /// <summary>
    /// Daire için ortak özellik ve method tanımlarını içeren base interface.
    /// </summary>
    interface IYuvarlakSekil // özellik açısından IKoseliSekil'den farklılaştığı için ayrı bir interface oluşturuyoruz
    {
        double Yaricap { get; set; } // property tanımı
        bool PiUcMu { get; set; } // property tanımı, true set edilirse PI 3, false set edilirse PI'nin gerçek değeri kullanılacak

        double CevreHesapla(); // method tanımı
        double AlanHesapla(); // method tanımı
    }
}
