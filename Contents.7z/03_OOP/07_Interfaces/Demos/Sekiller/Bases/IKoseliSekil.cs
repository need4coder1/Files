﻿namespace _07_Interfaces.Demos.Sekiller.Bases
{
    /// <summary>
    /// Kare, dikdörtgen ve diküçgen için ortak özellik ve method tanımlarını içeren base interface.
    /// </summary>
    interface IKoseliSekil
    {
        double Genislik { get; set; } // property tanımı
        double Yukseklik { get; set; } // property tanımı

        double CevreHesapla(); // method tanımı
        double AlanHesapla(); // method tanımı
    }
}
