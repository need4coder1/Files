﻿namespace _07_Interfaces
{
    // Kendisini implemente edecek Musteri ve Ogrenci class'ları için base abstract yapı.

    interface IKisi
    {
        //string _tcKimlikNo; // yanlış, interface'lerde field'lar (alan) kullanılamaz



        // property tanımları
        public string TcKimlikNo { get; set; } // property'ler (özellik) başında public yazılarak veya yazılmadan kullanılabilir,
                                               // genelde public yazılmaması tercih edilir, bu özelliğin imzasıdır

        string Adi { get; set; }

        string Soyadi { get; set; }



        // behavior (method) tanımları
        string Getir();
    }
}
