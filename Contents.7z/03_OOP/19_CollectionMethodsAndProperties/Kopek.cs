﻿namespace _18_CollectionMethods
{
    /// <summary>
    /// Köpek bilgilerini tutan concrete (somut) model class'ı.
    /// </summary>
    public class Kopek
    {
        #region Fields (Alanlar)
        string _adi;

        string _irki;

        byte _yasi;

        bool _erkekMi;
        #endregion



        #region Parametreli Constructor
        public Kopek(string adi, string irki, byte yasi, bool erkekMi)
        {
            _adi = adi;
            _irki = irki;
            _yasi = yasi;
            _erkekMi = erkekMi;
        }
        #endregion



        #region Override Edilen (Ezilen) Object Class'ının ToString Methodu
        public override string ToString()
        {
            return $"Köpek Adı: {_adi}\n" +
                $"Köpek Irkı: {_irki}\n" +
                $"Köpek Yaşı: {_yasi}\n" +
                $"Köpek Cinsiyeti: {(_erkekMi ? "Erkek" : "Dişi")}";
        }
        #endregion
    }
}
