﻿namespace _08_InterfaceSegregation._1_Arac
{
    interface IDireksiyon
    {
        // özellik tanımları
        bool DireksiyonSoldaMi { get; set; }
    }
}
