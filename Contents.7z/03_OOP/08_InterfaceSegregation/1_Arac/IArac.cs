﻿namespace _08_InterfaceSegregation._1_Arac
{
    interface IArac
    {
        // özellik tanımları
        int TekerlekSayisi { get; set; }
        YakitTipiEnum YakitTipi { get; set; }
        string Marka { get; set; }
        string Model { get; set; }
        int BeygirGucu { get; set; }
        int MotorHacmi { get; set; }



        // method tanımları
        string AracBilgileriniGetir(string satirSonu = " "); // satirSonu: aracın her bir özelliğini yazdırırken özellikler arasında kullanılacak ayraç
    }
}
