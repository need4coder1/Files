﻿namespace _08_InterfaceSegregation._1_Arac
{
    interface IKasaTipi
    {
        // özellik tanımları
        KasaTipiEnum KasaTipi { get; set; }
    }
}
