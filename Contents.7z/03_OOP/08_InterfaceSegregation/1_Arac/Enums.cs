﻿namespace _08_InterfaceSegregation._1_Arac
{
    enum YakitTipiEnum
    {
        Benzin,
        Dizel,
        Elektrik
    }

    enum KasaTipiEnum
    {
        Sedan,
        Hatchback,
        Cabrio,
        StationWagon
    }
}
