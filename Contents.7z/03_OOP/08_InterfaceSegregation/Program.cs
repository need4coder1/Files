﻿using _08_InterfaceSegregation._1_Arac;
using _08_InterfaceSegregation._2_Fabrika.DogruKullanim;
using _08_InterfaceSegregation._2_Fabrika.YanlisKullanim;

namespace _08_InterfaceSegregation
{
    internal class Program
    {
        // Interface Segregation yazılım geliştirme presinplerinden SOLID prensiplerinin I harfine karşılık gelir.
        // Bir interface oluşturup içerisine pek çok method tanımı yapıp bu interface'i implemente eden
        // bir veya daha fazla class'ta methodlardan bir veya daha fazlası implemente edilemiyorsa (içi boş kalıyorsa)
        // bu Interface Segregation prensibine aykırıdır ve asla yapılmamalıdır.
        // Bir sınıf bir interface'i implemente ettiğinde interface içerisindeki bütün özellik veya methodlar sınıfta
        // implemente edilmelidir (methodların içerisindeki kodlar yazılmalıdır).



        static void Main(string[] args)
        {
            #region Fabrika
            // Yanlış Kullanım Demo
            YanlisKullanimDemo.Calistir();

            Console.WriteLine();

            // Doğru Kullanım Demo
            DogruKullanimDemo.Calistir();

            Console.WriteLine();
            #endregion



            #region Araç
            AracDemo.Calistir();
            #endregion
        }
    }
}