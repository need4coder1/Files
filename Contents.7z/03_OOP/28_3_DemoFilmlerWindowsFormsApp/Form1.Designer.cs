﻿namespace _28_3_DemoFilmlerWindowsFormsApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvFilmler = new DataGridView();
            bAdaGoreFilmleriListele = new Button();
            panel1 = new Panel();
            tbAdi = new TextBox();
            label1 = new Label();
            groupBox1 = new GroupBox();
            ddlIslem = new ComboBox();
            tbId = new TextBox();
            label2 = new Label();
            bIdyeGoreFilmiGoster = new Button();
            lKayitSayisi = new Label();
            panel2 = new Panel();
            menuStrip1 = new MenuStrip();
            filmToolStripMenuItem = new ToolStripMenuItem();
            listeleToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem1 = new ToolStripSeparator();
            ekleToolStripMenuItem = new ToolStripMenuItem();
            düzenleToolStripMenuItem = new ToolStripMenuItem();
            silToolStripMenuItem = new ToolStripMenuItem();
            yönetmenlerToolStripMenuItem = new ToolStripMenuItem();
            türlerToolStripMenuItem = new ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)dgvFilmler).BeginInit();
            panel1.SuspendLayout();
            groupBox1.SuspendLayout();
            panel2.SuspendLayout();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // dgvFilmler
            // 
            dgvFilmler.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvFilmler.EditMode = DataGridViewEditMode.EditProgrammatically;
            dgvFilmler.Location = new Point(12, 36);
            dgvFilmler.Name = "dgvFilmler";
            dgvFilmler.RowTemplate.Height = 25;
            dgvFilmler.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvFilmler.Size = new Size(735, 200);
            dgvFilmler.TabIndex = 0;
            // 
            // bAdaGoreFilmleriListele
            // 
            bAdaGoreFilmleriListele.Location = new Point(227, 5);
            bAdaGoreFilmleriListele.Name = "bAdaGoreFilmleriListele";
            bAdaGoreFilmleriListele.Size = new Size(165, 23);
            bAdaGoreFilmleriListele.TabIndex = 2;
            bAdaGoreFilmleriListele.Text = "Ada Göre Filmleri Listele";
            bAdaGoreFilmleriListele.UseVisualStyleBackColor = true;
            bAdaGoreFilmleriListele.Click += bAdaGoreFilmleriListele_Click;
            // 
            // panel1
            // 
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(tbAdi);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(bAdaGoreFilmleriListele);
            panel1.Location = new Point(12, 283);
            panel1.Name = "panel1";
            panel1.Size = new Size(735, 38);
            panel1.TabIndex = 3;
            // 
            // tbAdi
            // 
            tbAdi.Location = new Point(46, 6);
            tbAdi.Name = "tbAdi";
            tbAdi.Size = new Size(175, 23);
            tbAdi.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(28, 15);
            label1.TabIndex = 3;
            label1.Text = "Adı:";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(ddlIslem);
            groupBox1.Location = new Point(12, 373);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(735, 60);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            groupBox1.Text = "Hızlı İşlemler";
            // 
            // ddlIslem
            // 
            ddlIslem.DropDownStyle = ComboBoxStyle.DropDownList;
            ddlIslem.FormattingEnabled = true;
            ddlIslem.Items.AddRange(new object[] { "-- İşlem Seçiniz --", "Film Ekle", "Film Düzenle", "Film Sil" });
            ddlIslem.Location = new Point(6, 22);
            ddlIslem.Name = "ddlIslem";
            ddlIslem.Size = new Size(216, 23);
            ddlIslem.TabIndex = 0;
            ddlIslem.SelectedIndexChanged += ddlIslem_SelectedIndexChanged;
            // 
            // tbId
            // 
            tbId.Location = new Point(45, 6);
            tbId.Name = "tbId";
            tbId.Size = new Size(175, 23);
            tbId.TabIndex = 7;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(11, 9);
            label2.Name = "label2";
            label2.Size = new Size(21, 15);
            label2.TabIndex = 6;
            label2.Text = "ID:";
            // 
            // bIdyeGoreFilmiGoster
            // 
            bIdyeGoreFilmiGoster.Location = new Point(226, 5);
            bIdyeGoreFilmiGoster.Name = "bIdyeGoreFilmiGoster";
            bIdyeGoreFilmiGoster.Size = new Size(165, 23);
            bIdyeGoreFilmiGoster.TabIndex = 5;
            bIdyeGoreFilmiGoster.Text = "ID'ye Göre Filmi Göster";
            bIdyeGoreFilmiGoster.UseVisualStyleBackColor = true;
            bIdyeGoreFilmiGoster.Click += bIdyeGoreFilmiGoster_Click;
            // 
            // lKayitSayisi
            // 
            lKayitSayisi.BackColor = Color.Black;
            lKayitSayisi.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lKayitSayisi.ForeColor = Color.White;
            lKayitSayisi.Location = new Point(12, 248);
            lKayitSayisi.Name = "lKayitSayisi";
            lKayitSayisi.Size = new Size(735, 23);
            lKayitSayisi.TabIndex = 5;
            lKayitSayisi.Text = "lKayitSayisi";
            lKayitSayisi.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            panel2.BorderStyle = BorderStyle.Fixed3D;
            panel2.Controls.Add(tbId);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(bIdyeGoreFilmiGoster);
            panel2.Location = new Point(12, 327);
            panel2.Name = "panel2";
            panel2.Size = new Size(735, 40);
            panel2.TabIndex = 6;
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { filmToolStripMenuItem, yönetmenlerToolStripMenuItem, türlerToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(759, 24);
            menuStrip1.TabIndex = 7;
            menuStrip1.Text = "menuStrip1";
            // 
            // filmToolStripMenuItem
            // 
            filmToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { listeleToolStripMenuItem, toolStripMenuItem1, ekleToolStripMenuItem, düzenleToolStripMenuItem, silToolStripMenuItem });
            filmToolStripMenuItem.Name = "filmToolStripMenuItem";
            filmToolStripMenuItem.Size = new Size(55, 20);
            filmToolStripMenuItem.Text = "Filmler";
            // 
            // listeleToolStripMenuItem
            // 
            listeleToolStripMenuItem.Name = "listeleToolStripMenuItem";
            listeleToolStripMenuItem.Size = new Size(116, 22);
            listeleToolStripMenuItem.Text = "Listele";
            listeleToolStripMenuItem.Click += listeleToolStripMenuItem_Click;
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(113, 6);
            // 
            // ekleToolStripMenuItem
            // 
            ekleToolStripMenuItem.Name = "ekleToolStripMenuItem";
            ekleToolStripMenuItem.Size = new Size(116, 22);
            ekleToolStripMenuItem.Text = "Ekle";
            ekleToolStripMenuItem.Click += ekleToolStripMenuItem_Click;
            // 
            // düzenleToolStripMenuItem
            // 
            düzenleToolStripMenuItem.Name = "düzenleToolStripMenuItem";
            düzenleToolStripMenuItem.Size = new Size(116, 22);
            düzenleToolStripMenuItem.Text = "Düzenle";
            düzenleToolStripMenuItem.Click += düzenleToolStripMenuItem_Click;
            // 
            // silToolStripMenuItem
            // 
            silToolStripMenuItem.Name = "silToolStripMenuItem";
            silToolStripMenuItem.Size = new Size(116, 22);
            silToolStripMenuItem.Text = "Sil";
            silToolStripMenuItem.Click += silToolStripMenuItem_Click;
            // 
            // yönetmenlerToolStripMenuItem
            // 
            yönetmenlerToolStripMenuItem.Name = "yönetmenlerToolStripMenuItem";
            yönetmenlerToolStripMenuItem.Size = new Size(86, 20);
            yönetmenlerToolStripMenuItem.Text = "Yönetmenler";
            yönetmenlerToolStripMenuItem.Click += yönetmenlerToolStripMenuItem_Click;
            // 
            // türlerToolStripMenuItem
            // 
            türlerToolStripMenuItem.Name = "türlerToolStripMenuItem";
            türlerToolStripMenuItem.Size = new Size(49, 20);
            türlerToolStripMenuItem.Text = "Türler";
            türlerToolStripMenuItem.Click += türlerToolStripMenuItem_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(759, 446);
            Controls.Add(panel2);
            Controls.Add(lKayitSayisi);
            Controls.Add(groupBox1);
            Controls.Add(panel1);
            Controls.Add(dgvFilmler);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Filmler Demo";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dgvFilmler).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            groupBox1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvFilmler;
        private Button bAdaGoreFilmleriListele;
        private Panel panel1;
        private TextBox tbAdi;
        private Label label1;
        private GroupBox groupBox1;
        private TextBox tbId;
        private Label label2;
        private Button bIdyeGoreFilmiGoster;
        private Label lKayitSayisi;
        private Panel panel2;
        private ComboBox ddlIslem;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem filmToolStripMenuItem;
        private ToolStripMenuItem ekleToolStripMenuItem;
        private ToolStripMenuItem düzenleToolStripMenuItem;
        private ToolStripMenuItem silToolStripMenuItem;
        private ToolStripMenuItem yönetmenlerToolStripMenuItem;
        private ToolStripMenuItem türlerToolStripMenuItem;
        private ToolStripMenuItem listeleToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem1;
    }
}