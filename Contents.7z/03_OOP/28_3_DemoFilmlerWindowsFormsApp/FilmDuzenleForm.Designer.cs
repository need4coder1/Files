﻿namespace _28_3_DemoFilmlerWindowsFormsApp
{
    partial class FilmDuzenleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            bGuncelle = new Button();
            bKapat = new Button();
            lMesaj = new Label();
            label6 = new Label();
            tbId = new TextBox();
            bGoster = new Button();
            panel1 = new Panel();
            cbYerli = new CheckBox();
            panel2 = new Panel();
            rbAmazon = new RadioButton();
            rbNetflix = new RadioButton();
            rbSinema = new RadioButton();
            label7 = new Label();
            dtpGosterimTarihi = new DateTimePicker();
            label1 = new Label();
            lbTurler = new ListBox();
            label5 = new Label();
            ddlYonetmen = new ComboBox();
            label4 = new Label();
            tbGisesi = new TextBox();
            label3 = new Label();
            nudYapimYili = new NumericUpDown();
            label2 = new Label();
            tbAdi = new TextBox();
            label8 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudYapimYili).BeginInit();
            SuspendLayout();
            // 
            // bGuncelle
            // 
            bGuncelle.Location = new Point(107, 433);
            bGuncelle.Name = "bGuncelle";
            bGuncelle.Size = new Size(75, 23);
            bGuncelle.TabIndex = 10;
            bGuncelle.Text = "Güncelle";
            bGuncelle.UseVisualStyleBackColor = true;
            bGuncelle.Click += bGuncelle_Click;
            // 
            // bKapat
            // 
            bKapat.Location = new Point(257, 433);
            bKapat.Name = "bKapat";
            bKapat.Size = new Size(75, 23);
            bKapat.TabIndex = 11;
            bKapat.Text = "Kapat";
            bKapat.UseVisualStyleBackColor = true;
            bKapat.Click += bKapat_Click;
            // 
            // lMesaj
            // 
            lMesaj.AutoSize = true;
            lMesaj.ForeColor = Color.Red;
            lMesaj.Location = new Point(107, 468);
            lMesaj.Name = "lMesaj";
            lMesaj.Size = new Size(41, 15);
            lMesaj.TabIndex = 12;
            lMesaj.Text = "lMesaj";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(5, 10);
            label6.Name = "label6";
            label6.Size = new Size(21, 15);
            label6.TabIndex = 13;
            label6.Text = "ID:";
            // 
            // tbId
            // 
            tbId.Location = new Point(93, 7);
            tbId.Name = "tbId";
            tbId.Size = new Size(137, 23);
            tbId.TabIndex = 14;
            // 
            // bGoster
            // 
            bGoster.Location = new Point(236, 6);
            bGoster.Name = "bGoster";
            bGoster.Size = new Size(75, 23);
            bGoster.TabIndex = 15;
            bGoster.Text = "Göster";
            bGoster.UseVisualStyleBackColor = true;
            bGoster.Click += bGoster_Click;
            // 
            // panel1
            // 
            panel1.BorderStyle = BorderStyle.Fixed3D;
            panel1.Controls.Add(tbId);
            panel1.Controls.Add(bGoster);
            panel1.Controls.Add(label6);
            panel1.Location = new Point(12, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(320, 45);
            panel1.TabIndex = 16;
            // 
            // cbYerli
            // 
            cbYerli.CheckAlign = ContentAlignment.MiddleRight;
            cbYerli.Location = new Point(12, 300);
            cbYerli.Name = "cbYerli";
            cbYerli.Size = new Size(109, 24);
            cbYerli.TabIndex = 33;
            cbYerli.Text = "Yerli Film:";
            cbYerli.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            panel2.Controls.Add(rbAmazon);
            panel2.Controls.Add(rbNetflix);
            panel2.Controls.Add(rbSinema);
            panel2.Location = new Point(98, 259);
            panel2.Name = "panel2";
            panel2.Size = new Size(234, 35);
            panel2.TabIndex = 32;
            // 
            // rbAmazon
            // 
            rbAmazon.AutoSize = true;
            rbAmazon.Location = new Point(145, 8);
            rbAmazon.Name = "rbAmazon";
            rbAmazon.Size = new Size(69, 19);
            rbAmazon.TabIndex = 2;
            rbAmazon.Text = "Amazon";
            rbAmazon.UseVisualStyleBackColor = true;
            // 
            // rbNetflix
            // 
            rbNetflix.AutoSize = true;
            rbNetflix.Location = new Point(79, 8);
            rbNetflix.Name = "rbNetflix";
            rbNetflix.Size = new Size(60, 19);
            rbNetflix.TabIndex = 1;
            rbNetflix.Text = "Netflix";
            rbNetflix.UseVisualStyleBackColor = true;
            // 
            // rbSinema
            // 
            rbSinema.AutoSize = true;
            rbSinema.Checked = true;
            rbSinema.Location = new Point(9, 8);
            rbSinema.Name = "rbSinema";
            rbSinema.Size = new Size(64, 19);
            rbSinema.TabIndex = 0;
            rbSinema.TabStop = true;
            rbSinema.Text = "Sinema";
            rbSinema.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(12, 269);
            label7.Name = "label7";
            label7.Size = new Size(56, 15);
            label7.TabIndex = 31;
            label7.Text = "Platform:";
            // 
            // dtpGosterimTarihi
            // 
            dtpGosterimTarihi.Format = DateTimePickerFormat.Short;
            dtpGosterimTarihi.Location = new Point(107, 221);
            dtpGosterimTarihi.Name = "dtpGosterimTarihi";
            dtpGosterimTarihi.Size = new Size(125, 23);
            dtpGosterimTarihi.TabIndex = 30;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 227);
            label1.Name = "label1";
            label1.Size = new Size(89, 15);
            label1.TabIndex = 29;
            label1.Text = "Gösterim Tarihi:";
            // 
            // lbTurler
            // 
            lbTurler.FormattingEnabled = true;
            lbTurler.ItemHeight = 15;
            lbTurler.Location = new Point(107, 339);
            lbTurler.Name = "lbTurler";
            lbTurler.SelectionMode = SelectionMode.MultiSimple;
            lbTurler.Size = new Size(225, 79);
            lbTurler.TabIndex = 28;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 339);
            label5.Name = "label5";
            label5.Size = new Size(43, 15);
            label5.TabIndex = 27;
            label5.Text = "Türleri:";
            // 
            // ddlYonetmen
            // 
            ddlYonetmen.DropDownStyle = ComboBoxStyle.DropDownList;
            ddlYonetmen.FormattingEnabled = true;
            ddlYonetmen.Location = new Point(107, 180);
            ddlYonetmen.Name = "ddlYonetmen";
            ddlYonetmen.Size = new Size(225, 23);
            ddlYonetmen.TabIndex = 26;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 183);
            label4.Name = "label4";
            label4.Size = new Size(67, 15);
            label4.TabIndex = 25;
            label4.Text = "Yönetmeni:";
            // 
            // tbGisesi
            // 
            tbGisesi.Location = new Point(107, 142);
            tbGisesi.Name = "tbGisesi";
            tbGisesi.Size = new Size(125, 23);
            tbGisesi.TabIndex = 24;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 145);
            label3.Name = "label3";
            label3.Size = new Size(40, 15);
            label3.TabIndex = 23;
            label3.Text = "Gişesi:";
            // 
            // nudYapimYili
            // 
            nudYapimYili.Location = new Point(107, 104);
            nudYapimYili.Maximum = new decimal(new int[] { 2100, 0, 0, 0 });
            nudYapimYili.Minimum = new decimal(new int[] { 1900, 0, 0, 0 });
            nudYapimYili.Name = "nudYapimYili";
            nudYapimYili.Size = new Size(75, 23);
            nudYapimYili.TabIndex = 22;
            nudYapimYili.Value = new decimal(new int[] { 1900, 0, 0, 0 });
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 106);
            label2.Name = "label2";
            label2.Size = new Size(62, 15);
            label2.TabIndex = 21;
            label2.Text = "Yapım Yılı:";
            // 
            // tbAdi
            // 
            tbAdi.Location = new Point(107, 66);
            tbAdi.Name = "tbAdi";
            tbAdi.Size = new Size(225, 23);
            tbAdi.TabIndex = 20;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(12, 69);
            label8.Name = "label8";
            label8.Size = new Size(28, 15);
            label8.TabIndex = 19;
            label8.Text = "Adı:";
            // 
            // FilmDuzenleForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(344, 496);
            Controls.Add(cbYerli);
            Controls.Add(panel2);
            Controls.Add(label7);
            Controls.Add(dtpGosterimTarihi);
            Controls.Add(label1);
            Controls.Add(lbTurler);
            Controls.Add(label5);
            Controls.Add(ddlYonetmen);
            Controls.Add(label4);
            Controls.Add(tbGisesi);
            Controls.Add(label3);
            Controls.Add(nudYapimYili);
            Controls.Add(label2);
            Controls.Add(tbAdi);
            Controls.Add(label8);
            Controls.Add(panel1);
            Controls.Add(lMesaj);
            Controls.Add(bKapat);
            Controls.Add(bGuncelle);
            Name = "FilmDuzenleForm";
            Text = "Film Düzenleme";
            Load += FilmDuzenleForm_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudYapimYili).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button bGuncelle;
        private Button bKapat;
        private Label lMesaj;
        private Label label6;
        private TextBox tbId;
        private Button bGoster;
        private Panel panel1;
        private CheckBox cbYerli;
        private Panel panel2;
        private RadioButton rbAmazon;
        private RadioButton rbNetflix;
        private RadioButton rbSinema;
        private Label label7;
        private DateTimePicker dtpGosterimTarihi;
        private Label label1;
        private ListBox lbTurler;
        private Label label5;
        private ComboBox ddlYonetmen;
        private Label label4;
        private TextBox tbGisesi;
        private Label label3;
        private NumericUpDown nudYapimYili;
        private Label label2;
        private TextBox tbAdi;
        private Label label8;
    }
}