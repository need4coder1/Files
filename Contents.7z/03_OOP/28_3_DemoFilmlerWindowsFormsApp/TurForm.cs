﻿using _28_1_DemoFilmlerClassLibrary.Repositories;

namespace _28_3_DemoFilmlerWindowsFormsApp
{
    public partial class TurForm : Form
    {
        TurRepo turRepo = new TurRepo();

        public TurForm()
        {
            InitializeComponent();
        }

        private void TurForm_Load(object sender, EventArgs e)
        {
            FillGrid();
        }

        void FillGrid()
        {
            dgvTurler.DataSource = turRepo.TurleriGetir();
            SetColumnVisibilitesAndNames();
        }

        void SetColumnVisibilitesAndNames()
        {
            dgvTurler.Columns["Adi"].HeaderText = "Adı";
            dgvTurler.Columns["Id"].HeaderText = "ID";
            dgvTurler.Columns["OlusturulmaTarihi"].HeaderText = "Oluşturulma Tarihi";

            dgvTurler.Columns["OlusturulmaTarihi"].Width = 130;

            dgvTurler.Columns["OlusturulmaTarihi"].DefaultCellStyle.Format = "dd.MM.yyyy HH:mm:ss";
        }
    }
}
