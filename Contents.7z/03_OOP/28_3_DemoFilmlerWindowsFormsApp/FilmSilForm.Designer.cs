﻿namespace _28_3_DemoFilmlerWindowsFormsApp
{
    partial class FilmSilForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lMesaj = new Label();
            bKapat = new Button();
            bSil = new Button();
            rtbFilm = new RichTextBox();
            panel1 = new Panel();
            tbId = new TextBox();
            bGoster = new Button();
            label6 = new Label();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // lMesaj
            // 
            lMesaj.AutoSize = true;
            lMesaj.ForeColor = Color.Red;
            lMesaj.Location = new Point(12, 347);
            lMesaj.Name = "lMesaj";
            lMesaj.Size = new Size(41, 15);
            lMesaj.TabIndex = 21;
            lMesaj.Text = "lMesaj";
            // 
            // bKapat
            // 
            bKapat.Location = new Point(252, 312);
            bKapat.Name = "bKapat";
            bKapat.Size = new Size(75, 23);
            bKapat.TabIndex = 20;
            bKapat.Text = "Kapat";
            bKapat.UseVisualStyleBackColor = true;
            bKapat.Click += bKapat_Click;
            // 
            // bSil
            // 
            bSil.Location = new Point(12, 312);
            bSil.Name = "bSil";
            bSil.Size = new Size(75, 23);
            bSil.TabIndex = 19;
            bSil.Text = "Sil";
            bSil.UseVisualStyleBackColor = true;
            bSil.Click += bSil_Click;
            // 
            // rtbFilm
            // 
            rtbFilm.Location = new Point(12, 74);
            rtbFilm.Name = "rtbFilm";
            rtbFilm.ReadOnly = true;
            rtbFilm.Size = new Size(320, 222);
            rtbFilm.TabIndex = 22;
            rtbFilm.Text = "";
            // 
            // panel1
            // 
            panel1.BorderStyle = BorderStyle.Fixed3D;
            panel1.Controls.Add(tbId);
            panel1.Controls.Add(bGoster);
            panel1.Controls.Add(label6);
            panel1.Location = new Point(12, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(320, 45);
            panel1.TabIndex = 23;
            // 
            // tbId
            // 
            tbId.Location = new Point(93, 7);
            tbId.Name = "tbId";
            tbId.Size = new Size(137, 23);
            tbId.TabIndex = 14;
            // 
            // bGoster
            // 
            bGoster.Location = new Point(236, 6);
            bGoster.Name = "bGoster";
            bGoster.Size = new Size(75, 23);
            bGoster.TabIndex = 15;
            bGoster.Text = "Göster";
            bGoster.UseVisualStyleBackColor = true;
            bGoster.Click += bGoster_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(5, 10);
            label6.Name = "label6";
            label6.Size = new Size(21, 15);
            label6.TabIndex = 13;
            label6.Text = "ID:";
            // 
            // FilmSilForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(344, 371);
            Controls.Add(panel1);
            Controls.Add(rtbFilm);
            Controls.Add(lMesaj);
            Controls.Add(bKapat);
            Controls.Add(bSil);
            Name = "FilmSilForm";
            Text = "Film Silme";
            Load += FilmSilForm_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label lMesaj;
        private Button bKapat;
        private Button bSil;
        private RichTextBox rtbFilm;
        private Panel panel1;
        private TextBox tbId;
        private Button bGoster;
        private Label label6;
    }
}