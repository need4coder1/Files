﻿namespace _28_3_DemoFilmlerWindowsFormsApp
{
    partial class TurForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvTurler = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgvTurler).BeginInit();
            SuspendLayout();
            // 
            // dgvTurler
            // 
            dgvTurler.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvTurler.Dock = DockStyle.Fill;
            dgvTurler.EditMode = DataGridViewEditMode.EditProgrammatically;
            dgvTurler.Location = new Point(0, 0);
            dgvTurler.Name = "dgvTurler";
            dgvTurler.RowTemplate.Height = 25;
            dgvTurler.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvTurler.Size = new Size(759, 226);
            dgvTurler.TabIndex = 2;
            // 
            // TurForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(759, 226);
            Controls.Add(dgvTurler);
            Name = "TurForm";
            Text = "Türler";
            Load += TurForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgvTurler).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dgvTurler;
    }
}