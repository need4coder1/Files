﻿namespace _28_3_DemoFilmlerWindowsFormsApp
{
    partial class FilmEkleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            tbAdi = new TextBox();
            label2 = new Label();
            nudYapimYili = new NumericUpDown();
            label3 = new Label();
            tbGisesi = new TextBox();
            label4 = new Label();
            ddlYonetmen = new ComboBox();
            label5 = new Label();
            lbTurler = new ListBox();
            bEkle = new Button();
            bKapat = new Button();
            lMesaj = new Label();
            label6 = new Label();
            dtpGosterimTarihi = new DateTimePicker();
            label7 = new Label();
            panel1 = new Panel();
            rbAmazon = new RadioButton();
            rbNetflix = new RadioButton();
            rbSinema = new RadioButton();
            cbYerli = new CheckBox();
            ((System.ComponentModel.ISupportInitialize)nudYapimYili).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 15);
            label1.Name = "label1";
            label1.Size = new Size(28, 15);
            label1.TabIndex = 0;
            label1.Text = "Adı:";
            // 
            // tbAdi
            // 
            tbAdi.Location = new Point(107, 12);
            tbAdi.Name = "tbAdi";
            tbAdi.Size = new Size(225, 23);
            tbAdi.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 52);
            label2.Name = "label2";
            label2.Size = new Size(62, 15);
            label2.TabIndex = 2;
            label2.Text = "Yapım Yılı:";
            // 
            // nudYapimYili
            // 
            nudYapimYili.Location = new Point(107, 50);
            nudYapimYili.Maximum = new decimal(new int[] { 2100, 0, 0, 0 });
            nudYapimYili.Minimum = new decimal(new int[] { 1900, 0, 0, 0 });
            nudYapimYili.Name = "nudYapimYili";
            nudYapimYili.Size = new Size(75, 23);
            nudYapimYili.TabIndex = 3;
            nudYapimYili.Value = new decimal(new int[] { 1900, 0, 0, 0 });
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 91);
            label3.Name = "label3";
            label3.Size = new Size(40, 15);
            label3.TabIndex = 4;
            label3.Text = "Gişesi:";
            // 
            // tbGisesi
            // 
            tbGisesi.Location = new Point(107, 88);
            tbGisesi.Name = "tbGisesi";
            tbGisesi.Size = new Size(125, 23);
            tbGisesi.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 129);
            label4.Name = "label4";
            label4.Size = new Size(67, 15);
            label4.TabIndex = 6;
            label4.Text = "Yönetmeni:";
            // 
            // ddlYonetmen
            // 
            ddlYonetmen.DropDownStyle = ComboBoxStyle.DropDownList;
            ddlYonetmen.FormattingEnabled = true;
            ddlYonetmen.Location = new Point(107, 126);
            ddlYonetmen.Name = "ddlYonetmen";
            ddlYonetmen.Size = new Size(225, 23);
            ddlYonetmen.TabIndex = 7;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 285);
            label5.Name = "label5";
            label5.Size = new Size(43, 15);
            label5.TabIndex = 8;
            label5.Text = "Türleri:";
            // 
            // lbTurler
            // 
            lbTurler.FormattingEnabled = true;
            lbTurler.ItemHeight = 15;
            lbTurler.Location = new Point(107, 285);
            lbTurler.Name = "lbTurler";
            lbTurler.SelectionMode = SelectionMode.MultiSimple;
            lbTurler.Size = new Size(225, 79);
            lbTurler.TabIndex = 9;
            // 
            // bEkle
            // 
            bEkle.Location = new Point(107, 379);
            bEkle.Name = "bEkle";
            bEkle.Size = new Size(75, 23);
            bEkle.TabIndex = 10;
            bEkle.Text = "Ekle";
            bEkle.UseVisualStyleBackColor = true;
            bEkle.Click += bEkle_Click;
            // 
            // bKapat
            // 
            bKapat.Location = new Point(257, 379);
            bKapat.Name = "bKapat";
            bKapat.Size = new Size(75, 23);
            bKapat.TabIndex = 11;
            bKapat.Text = "Kapat";
            bKapat.UseVisualStyleBackColor = true;
            bKapat.Click += bKapat_Click;
            // 
            // lMesaj
            // 
            lMesaj.AutoSize = true;
            lMesaj.ForeColor = Color.Red;
            lMesaj.Location = new Point(107, 414);
            lMesaj.Name = "lMesaj";
            lMesaj.Size = new Size(41, 15);
            lMesaj.TabIndex = 12;
            lMesaj.Text = "lMesaj";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(12, 173);
            label6.Name = "label6";
            label6.Size = new Size(89, 15);
            label6.TabIndex = 13;
            label6.Text = "Gösterim Tarihi:";
            // 
            // dtpGosterimTarihi
            // 
            dtpGosterimTarihi.Format = DateTimePickerFormat.Short;
            dtpGosterimTarihi.Location = new Point(107, 167);
            dtpGosterimTarihi.Name = "dtpGosterimTarihi";
            dtpGosterimTarihi.Size = new Size(125, 23);
            dtpGosterimTarihi.TabIndex = 14;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(12, 215);
            label7.Name = "label7";
            label7.Size = new Size(56, 15);
            label7.TabIndex = 15;
            label7.Text = "Platform:";
            // 
            // panel1
            // 
            panel1.Controls.Add(rbAmazon);
            panel1.Controls.Add(rbNetflix);
            panel1.Controls.Add(rbSinema);
            panel1.Location = new Point(99, 205);
            panel1.Name = "panel1";
            panel1.Size = new Size(233, 35);
            panel1.TabIndex = 16;
            // 
            // rbAmazon
            // 
            rbAmazon.AutoSize = true;
            rbAmazon.Location = new Point(144, 8);
            rbAmazon.Name = "rbAmazon";
            rbAmazon.Size = new Size(69, 19);
            rbAmazon.TabIndex = 2;
            rbAmazon.Text = "Amazon";
            rbAmazon.UseVisualStyleBackColor = true;
            // 
            // rbNetflix
            // 
            rbNetflix.AutoSize = true;
            rbNetflix.Location = new Point(78, 8);
            rbNetflix.Name = "rbNetflix";
            rbNetflix.Size = new Size(60, 19);
            rbNetflix.TabIndex = 1;
            rbNetflix.Text = "Netflix";
            rbNetflix.UseVisualStyleBackColor = true;
            // 
            // rbSinema
            // 
            rbSinema.AutoSize = true;
            rbSinema.Checked = true;
            rbSinema.Location = new Point(8, 8);
            rbSinema.Name = "rbSinema";
            rbSinema.Size = new Size(64, 19);
            rbSinema.TabIndex = 0;
            rbSinema.TabStop = true;
            rbSinema.Text = "Sinema";
            rbSinema.UseVisualStyleBackColor = true;
            // 
            // cbYerli
            // 
            cbYerli.CheckAlign = ContentAlignment.MiddleRight;
            cbYerli.Location = new Point(12, 246);
            cbYerli.Name = "cbYerli";
            cbYerli.Size = new Size(109, 24);
            cbYerli.TabIndex = 18;
            cbYerli.Text = "Yerli Film:";
            cbYerli.UseVisualStyleBackColor = true;
            // 
            // FilmEkleForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(344, 436);
            Controls.Add(cbYerli);
            Controls.Add(panel1);
            Controls.Add(label7);
            Controls.Add(dtpGosterimTarihi);
            Controls.Add(label6);
            Controls.Add(lMesaj);
            Controls.Add(bKapat);
            Controls.Add(bEkle);
            Controls.Add(lbTurler);
            Controls.Add(label5);
            Controls.Add(ddlYonetmen);
            Controls.Add(label4);
            Controls.Add(tbGisesi);
            Controls.Add(label3);
            Controls.Add(nudYapimYili);
            Controls.Add(label2);
            Controls.Add(tbAdi);
            Controls.Add(label1);
            Name = "FilmEkleForm";
            Text = "Film Ekleme";
            Load += FilmEkleForm_Load;
            ((System.ComponentModel.ISupportInitialize)nudYapimYili).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox tbAdi;
        private Label label2;
        private NumericUpDown nudYapimYili;
        private Label label3;
        private TextBox tbGisesi;
        private Label label4;
        private ComboBox ddlYonetmen;
        private Label label5;
        private ListBox lbTurler;
        private Button bEkle;
        private Button bKapat;
        private Label lMesaj;
        private Label label6;
        private DateTimePicker dtpGosterimTarihi;
        private Label label7;
        private Panel panel1;
        private RadioButton rbSinema;
        private RadioButton rbNetflix;
        private RadioButton rbAmazon;
        private CheckBox cbYerli;
    }
}