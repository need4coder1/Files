﻿namespace _28_3_DemoFilmlerWindowsFormsApp
{
    partial class YonetmenForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvYonetmenler = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgvYonetmenler).BeginInit();
            SuspendLayout();
            // 
            // dgvYonetmenler
            // 
            dgvYonetmenler.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvYonetmenler.Dock = DockStyle.Fill;
            dgvYonetmenler.EditMode = DataGridViewEditMode.EditProgrammatically;
            dgvYonetmenler.Location = new Point(0, 0);
            dgvYonetmenler.Name = "dgvYonetmenler";
            dgvYonetmenler.RowTemplate.Height = 25;
            dgvYonetmenler.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvYonetmenler.Size = new Size(759, 226);
            dgvYonetmenler.TabIndex = 1;
            // 
            // YonetmenForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(759, 226);
            Controls.Add(dgvYonetmenler);
            Name = "YonetmenForm";
            Text = "Yönetmenler";
            Load += YonetmenForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgvYonetmenler).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dgvYonetmenler;
    }
}