﻿using _28_1_DemoFilmlerClassLibrary.Repositories;

namespace _28_3_DemoFilmlerWindowsFormsApp
{
    public partial class YonetmenForm : Form
    {
        YonetmenRepo yonetmenRepo = new YonetmenRepo();

        public YonetmenForm()
        {
            InitializeComponent();
        }

        private void YonetmenForm_Load(object sender, EventArgs e)
        {
            FillGrid();
        }

        void FillGrid()
        {
            dgvYonetmenler.DataSource = yonetmenRepo.YonetmenleriGetir();
            SetColumnVisibilitesAndNames();
        }

        void SetColumnVisibilitesAndNames()
        {
            dgvYonetmenler.Columns["Adi"].HeaderText = "Adı";
            dgvYonetmenler.Columns["Soyadi"].HeaderText = "Soyadı";
            dgvYonetmenler.Columns["DogumTarihi"].HeaderText = "Doğum Tarihi";
            dgvYonetmenler.Columns["EmekliMi"].HeaderText = "Emekli";
            dgvYonetmenler.Columns["Id"].HeaderText = "ID";
            dgvYonetmenler.Columns["OlusturulmaTarihi"].HeaderText = "Oluşturulma Tarihi";

            dgvYonetmenler.Columns["DogumTarihi"].DefaultCellStyle.Format = "dd.MM.yyyy";
            dgvYonetmenler.Columns["OlusturulmaTarihi"].DefaultCellStyle.Format = "dd.MM.yyyy HH:mm:ss";

            dgvYonetmenler.Columns["AdiSoyadi"].Visible = false;

            dgvYonetmenler.Columns["DogumTarihi"].Width = 115;
            dgvYonetmenler.Columns["OlusturulmaTarihi"].Width = 130;
        }
    }
}
