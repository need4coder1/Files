﻿using _14_ArrayOfObjects_TimeSpan_Casting.Models.Bases;

namespace _14_ArrayOfObjects_TimeSpan_Casting.Models
{
    /// <summary>
    /// Medya class'ını inherit eden sub concrete model class'ı.
    /// </summary>
    class Sarki : Medya // Sarki bir Medya'dır şeklinde de okunabilir (is-a relationship)
    {
        #region Properties
        public string Sanatci { get; set; }
        public string Album { get; set; }
        public bool Mp3mu { get; set; } = true; // mp3 ise true diğer formatlarda ise false,
                                                // en sık mp3 formatı kullanıldığından her Sarki objesini new'lerken özelliğe true değerini
                                                // atamak zorunda kalmayalım diye (eğer true atamazsak false atanır) default olarak true değerini atadık
        #endregion
    }
}
