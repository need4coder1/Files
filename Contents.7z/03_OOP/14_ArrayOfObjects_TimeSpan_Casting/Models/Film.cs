﻿using _14_ArrayOfObjects_TimeSpan_Casting.Models.Bases;

namespace _14_ArrayOfObjects_TimeSpan_Casting.Models
{
    /// <summary>
    /// Video ve Video üzerinden Medya class'larından inherit eden sub concrete model class'ı.
    /// </summary>
    class Film : Video // Film bir Video'dur şeklinde de okunabilir (is-a relationship)
    {
        public string Yonetmen { get; set; }
        public string[] Oyuncular { get; set; }
        public float ImdbPuani { get; set; }
    }
}
