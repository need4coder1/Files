﻿using _14_ArrayOfObjects_TimeSpan_Casting.Enums;

namespace _14_ArrayOfObjects_TimeSpan_Casting.Models.Bases
{
    /// <summary>
    /// Medya class'ını inherit eden sub concrete model class'ı.
    /// </summary>
    class Video : Medya // Video bir Medya'dır şeklinde de okunabilir (is-a relationship),
                        // eğer uygulamada Video tipinde obje kullanılmayacaksa (new'lenmeyecekse) abstract (soyut) da tanımlanabilir
    {
        #region Properties
        public GoruntuFormati GoruntuFormati { get; set; } // soldaki GoruntuFormati enum tipi, sağdaki özellik adı
        #endregion
    }
}
