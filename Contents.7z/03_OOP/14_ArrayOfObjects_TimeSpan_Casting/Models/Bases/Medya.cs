﻿namespace _14_ArrayOfObjects_TimeSpan_Casting.Models.Bases
{
    /// <summary>
    /// Video ile Video class'ı üzerinden Film ve ayrıca Muzik class'larının base concrete model class'ı.
    /// </summary>
    class Medya // eğer uygulamada Medya tipinde obje kullanılmayacaksa (new'lenmeyecekse) abstract (soyut) da tanımlanabilir
    {
        #region Properties
        public string Adi { get; set; }
        public TimeSpan Suresi { get; set; } // TimeSpan veri tipi (struct) süre için kullanılır
        public DateTime CikisTarihi { get; set; }
        public decimal TLfiyati { get; set; }
        #endregion
    }
}
