﻿namespace _14_ArrayOfObjects_TimeSpan_Casting.Enums
{
    /// <summary>
    /// Ultra High Definition (Ultra HD), High Definition (HD) ve Standard Definition (SD) görüntü formatları için enum.
    /// </summary>
    enum GoruntuFormati
    {
        // elemanlara herhangi bir değer ataması yapmadığımız için UltraHD'nin değeri 0 olacak ve diğerleri de otomatik 1 artacak
        UltraHD,
        HD,
        SD
    }
}
