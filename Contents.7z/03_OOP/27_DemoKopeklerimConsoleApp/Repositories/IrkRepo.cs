﻿using _27_DemoKopeklerimConsoleApp.Data;
using _27_DemoKopeklerimConsoleApp.Entities;
using _27_DemoKopeklerimConsoleApp.Entities.Bases;
using _27_DemoKopeklerimConsoleApp.Repositories.Bases;

namespace _27_DemoKopeklerimConsoleApp.Repositories
{
    public class IrkRepo : IRepo
    {
        public List<Irk> IrklariGetir()
        {
            return Veriler.Irklar;
        }

        public Kayit KayitGetir(int id)
        {
            Kayit kayit = null;
            List<Irk> irklar = IrklariGetir();
            foreach (Irk irk in irklar)
            {
                if (irk.Id == id)
                {
                    kayit = irk;
                    break;
                }
            }
            return kayit;
        }
    }
}
