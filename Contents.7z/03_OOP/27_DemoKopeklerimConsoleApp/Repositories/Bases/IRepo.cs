﻿using _27_DemoKopeklerimConsoleApp.Entities.Bases;

namespace _27_DemoKopeklerimConsoleApp.Repositories.Bases
{
    public interface IRepo
    {
        Kayit KayitGetir(int id);
    }
}
