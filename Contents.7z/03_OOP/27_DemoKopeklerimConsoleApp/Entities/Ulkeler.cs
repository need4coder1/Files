﻿namespace _27_DemoKopeklerimConsoleApp.Entities
{
    public enum Ulkeler
    {
        Türkiye,
        İskoçya,
        İrlanda,
        İngiltere,
        Almanya
    }
}
