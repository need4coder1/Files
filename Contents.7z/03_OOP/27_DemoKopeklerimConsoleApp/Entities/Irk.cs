﻿using _27_DemoKopeklerimConsoleApp.Entities.Bases;

namespace _27_DemoKopeklerimConsoleApp.Entities
{
    public class Irk : Kayit
    {
        public string Adi { get; set; }
        public Ulkeler Ulkesi { get; set; }

        public Irk(string adi, Ulkeler ulkesi, int id) : base(id)
        {
            Adi = adi;
            Ulkesi = ulkesi;
        }
    }
}
