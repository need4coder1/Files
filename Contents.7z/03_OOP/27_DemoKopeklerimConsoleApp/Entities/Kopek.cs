﻿using _27_DemoKopeklerimConsoleApp.Entities.Bases;

namespace _27_DemoKopeklerimConsoleApp.Entities
{
    public class Kopek : Kayit
    {
        public string Adi { get; set; }
        public DateTime DogumTarihi { get; set; }
        public bool ErkekMi { get; set; }
        public Irk Irki { get; set; }
        public double Boyu { get; set; } // cm
        public double Kilosu { get; set; } // kg
    }
}
