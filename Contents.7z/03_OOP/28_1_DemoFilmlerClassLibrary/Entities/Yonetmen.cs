﻿using _28_1_DemoFilmlerClassLibrary.Entities.Bases;

namespace _28_1_DemoFilmlerClassLibrary.Entities
{
    public class Yonetmen : Kayit
    {
        public string Adi { get; set; }
        public string Soyadi { get; set; }
        public DateTime DogumTarihi { get; set; }
        public bool EmekliMi { get; set; }

        public string AdiSoyadi => (Adi + " " + Soyadi).Trim();

        public override string ToString() => AdiSoyadi;
    }
}
