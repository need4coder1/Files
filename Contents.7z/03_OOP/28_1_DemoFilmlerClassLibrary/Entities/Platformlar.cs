﻿namespace _28_1_DemoFilmlerClassLibrary.Entities
{
    public enum Platformlar
    {
        Sinema = 1,
        Netflix,
        Amazon
    }
}
