﻿using _28_1_DemoFilmlerClassLibrary.Entities.Bases;

namespace _28_1_DemoFilmlerClassLibrary.Entities
{
    public class Tur : Kayit
    {
        public string Adi { get; set; }

        public Tur(string adi, int id) : base(id)
        {
            Adi = adi;
        }
    }
}
