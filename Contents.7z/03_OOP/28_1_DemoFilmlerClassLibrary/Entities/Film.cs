﻿using _28_1_DemoFilmlerClassLibrary.Entities.Bases;

namespace _28_1_DemoFilmlerClassLibrary.Entities
{
    public class Film : Kayit
    {
        public string Adi { get; set; }
        public short YapimYili { get; set; }
        public decimal Gisesi { get; set; }
        public Yonetmen Yonetmeni { get; set; }
        public bool YerliMi { get; set; }
        public DateTime GosterimTarihi { get; set; }
        public Platformlar Platform { get; set; }
        public List<Tur> Turleri { get; set; }

        public Film()
        {
            Turleri = new List<Tur>();
        }
    }
}
