﻿using _28_1_DemoFilmlerClassLibrary.Data;
using _28_1_DemoFilmlerClassLibrary.Entities;
using _28_1_DemoFilmlerClassLibrary.Entities.Bases;
using _28_1_DemoFilmlerClassLibrary.Repositories.Bases;

namespace _28_1_DemoFilmlerClassLibrary.Repositories
{
    public class YonetmenRepo : IRepo
    {
        public List<Yonetmen> YonetmenleriGetir()
        {
            return Veriler.Yonetmenler;
        }

        public Kayit KayitGetir(int id)
        {
            Yonetmen yonetmen = null;
            var mevcutYonetmenler = YonetmenleriGetir();
            foreach (var mevcutYonetmen in mevcutYonetmenler)
            {
                if (mevcutYonetmen.Id == id)
                {
                    yonetmen = mevcutYonetmen;
                    break;
                }
            }
            return yonetmen;
        }
    }
}
