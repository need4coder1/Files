﻿using _28_1_DemoFilmlerClassLibrary.Entities.Bases;

namespace _28_1_DemoFilmlerClassLibrary.Repositories.Bases
{
    public interface IRepo
    {
        Kayit KayitGetir(int id);
    }
}
