﻿using _28_1_DemoFilmlerClassLibrary.Data;
using _28_1_DemoFilmlerClassLibrary.Entities;
using _28_1_DemoFilmlerClassLibrary.Entities.Bases;
using _28_1_DemoFilmlerClassLibrary.Repositories.Bases;

namespace _28_1_DemoFilmlerClassLibrary.Repositories
{
    public class TurRepo : IRepo
    {
        public List<Tur> TurleriGetir()
        {
            return Veriler.Turler;
        }

        public List<Tur> TurleriGetir(List<int> turIdleri)
        {
            List<Tur> turler = new List<Tur>();
            List<Tur> mevcutTurler = TurleriGetir();
            bool turBulundu;
            foreach (int turId in turIdleri)
            {
                foreach (Tur mevcutTur in mevcutTurler)
                {
                    if (turId == mevcutTur.Id)
                    {
                        turler.Add(mevcutTur);
                        break;
                    }
                }
            }
            return turler;
        }

        public Kayit KayitGetir(int id)
        {
            Tur tur = null;
            var mevcutTurler = TurleriGetir();
            foreach (var mevcutTur in mevcutTurler)
            {
                if (mevcutTur.Id == id)
                {
                    tur = mevcutTur;
                    break;
                }
            }
            return tur;
        }
    }
}
