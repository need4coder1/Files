﻿namespace _26_RecursiveMethods.Demos.TasKagitMakas.Services.Bases
{
    /// <summary>
    /// TasKagitMakasService sınıfına implemente edilecek soyut interface.
    /// </summary>
    public interface ITasKagitMakasService
    {
        #region Method Definitions
        public void YeniOyunaBasla(); // public yazılmasa da olur

        public string Oyna(char oyuncuHareketi, string sonuc = null); // public yazılmasa da olur
        #endregion
    }
}
