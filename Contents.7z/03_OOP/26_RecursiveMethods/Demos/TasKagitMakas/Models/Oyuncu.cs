﻿using _26_RecursiveMethods.Demos.TasKagitMakas.Models.Bases;

namespace _26_RecursiveMethods.Demos.TasKagitMakas.Models
{
    public class Oyuncu : OyuncuBase
    {
    }
}
