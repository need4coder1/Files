﻿namespace _26_RecursiveMethods.Demos.TasKagitMakas.Models.Bases
{
    /// <summary>
    /// Oyuncu class'ının miras alacağı soyut class.
    /// </summary>
    public abstract class OyuncuBase
    {
        #region Properties
        public string Rumuzu { get; set; }
        public int KazanmaSayisi { get; set; }
        #endregion
    }
}
