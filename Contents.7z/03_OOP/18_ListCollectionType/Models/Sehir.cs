﻿namespace _18_ListCollectionType.Models
{
    /// <summary>
    /// Şehir bilgileri için somut model sınıfı.
    /// </summary>
    public class Sehir
    {
        #region Properties
        public byte PlakaNo { get; set; }

        public string Adi { get; set; }
        #endregion



        #region Constructors
        public Sehir()
        {
            
        }

        public Sehir(byte plakaNo, string adi)
        {
            PlakaNo = plakaNo;
            Adi = adi;
        }
        #endregion
    }
}
