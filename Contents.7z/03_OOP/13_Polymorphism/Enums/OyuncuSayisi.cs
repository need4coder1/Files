﻿namespace _13_Polymorphism.Enums
{
    /// <summary>
    /// Oyuncu sayılarını için kullanılacak enum.
    /// </summary>
    enum OyuncuSayisi
    {
        TekOyuncu = 1,
        ÇokOyuncu, // ilk TekOyuncu'ya 1 ataması yaptığımızdan değeri 2 olacaktır
        HemTekHemÇokOyuncu // ilk TekOyuncu'ya 1 ataması yaptığımızdan değeri 3 olacaktır
    }
}
