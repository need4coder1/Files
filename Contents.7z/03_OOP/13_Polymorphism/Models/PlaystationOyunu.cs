﻿using _13_Polymorphism.Models.Bases;

namespace _13_Polymorphism.Models
{
    class PlaystationOyunu : VideoOyunu // PlaystationOyunu sub (child) class'ı VideoOyunu base (parent) class'ından miras alır,
                                        // PlaystationOyunu bir VideoOyunu'dur şeklinde de okunabilir (is-a relationship)
    {
        /// <summary>
        /// Oyunun çalışabileceği Playstation modelleri. 4, 5, vb.
        /// </summary>
        public byte[] Modelleri { get; set; }
    }
}
