﻿namespace _22_DependencyInjection.Demos.Bases
{
    public abstract class SurucuBase // Araba sınıfına enjekte edilecek sürücü objesinin soyut sınıfı
    {
        public string Isim { get; set; }
    }
}
