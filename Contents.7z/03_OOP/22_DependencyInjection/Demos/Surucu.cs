﻿using _22_DependencyInjection.Demos.Bases;

namespace _22_DependencyInjection.Demos
{
    public class Surucu : SurucuBase // Araba objesine new'lenerek enjekte edilecek sürücü objesinin somut sınıfı
    {
    }
}
