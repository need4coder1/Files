﻿using _22_DependencyInjection.Logging.Bases;

namespace _22_DependencyInjection.Logging.Repositories
{
    public class CategoryRepo // kategori güncelleme işlemini gerçekleştiren somut repository class'ı
    {
        public ILogger Logger { get; set; } // enjekte edilmek istenen obje tipinde bir özellik tanımlanır

        public void Update() // güncelleme methodu hem kategori güncelleme işlemini gerçekleştirir hem de enjekte edilen
                             // Logger özelliği üzerinden loglama işlemi gerçekleştirilir
        {
            Console.WriteLine("Kategori güncellendi.");
            Logger.Log();
        }
    }
}
