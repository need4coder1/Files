﻿using _22_DependencyInjection.Logging.Bases;

namespace _22_DependencyInjection.Logging.Repositories
{
    public class StoreRepo // mağaza listeleme ve detay getirme işlemlerini gerçekleştiren somut repository class'ı
    {
        public void GetList(ILogger logger) // listeleme methodu hem mağaza listeleme işlemini gerçekleştirir hem de enjekte edilen
                                            // logger parametresi üzerinden loglama işlemi gerçekleştirilir
        {
            Console.WriteLine("Mağazalar listelendi.");
            logger.Log();
        }

        public void GetDetails(ILogger logger) // detay getirme methodu hem mağaza detayının getirilmesi işlemini gerçekleştirir
                                               // hem de enjekte edilen logger parametresi üzerinden loglama işlemi gerçekleştirilir
        {
            Console.WriteLine("Mağaza detayı getirildi.");
            logger.Log();
        }
    }
}
