﻿using _22_DependencyInjection.Logging.Bases;

namespace _22_DependencyInjection.Logging
{
    public class FileLogger : ILogger // dosya loglama işlemleri için somut class
    {
        public void Log() // loglama işlemini yapacak method implementasyonu
        {
            Console.WriteLine("Dosyaya loglandı.\n");
        }
    }
}
