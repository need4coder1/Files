﻿namespace _22_DependencyInjection.Logging.Bases
{
    public interface ILogger // loglama işlemleri için soyut interface
    {
        void Log(); // loglama işlemini yapacak method tanımı
    }
}
