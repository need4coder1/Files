﻿using _12_InterfacesVsAbstractClasses._1_InterfaceOrnegi;
using _12_InterfacesVsAbstractClasses._2_AbstractClassOrnegi;

namespace _12_InterfacesVsAbstractClasses
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Aradaki farklar için önce 1_InterfaceOrnegi -> Bases -> IOgrenciDosya daha sonra 2_AbstractClassOrnegi -> Bases -> OgrenciDosyaBase sınıflarına bakılmalıdır.
            // Bu örnek için abstract class kullanmak daha uygundur.

            #region 1 - Interface Örneği
            InterfaceDemo.Calistir();
            #endregion

            Console.WriteLine();

            #region 2 - Abstract Class Örneği
            AbstractClassDemo.Calistir();
            #endregion
        }
    }
}