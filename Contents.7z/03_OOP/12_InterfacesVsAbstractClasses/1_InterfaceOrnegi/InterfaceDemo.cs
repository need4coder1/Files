﻿namespace _12_InterfacesVsAbstractClasses._1_InterfaceOrnegi
{
    public class InterfaceDemo
    {
        public static void Calistir()
        {
            MetinselOgrenciDosya ogrenciDosya = new MetinselOgrenciDosya() // ogrenciDosya instance'ı (new'lenmiş obje)
            {
                //DosyaYolu = @"C:\TMP\Öğrenciler.txt" 
                // 1. yöntem: örnek dosyalar için bu projenin Dosyalar klasöründeki Öğrenciler.txt dosyası
                // C:\TMP klasörü altına kopyalanabilir

                DosyaYolu = "../../../Dosyalar/Öğrenciler.txt"
                // 2. yöntem: örnek dosya için projenin exe dosyasının bulunduğu klasörden, "/" ile ayrılarak
                // ".." ile üst klasörlere ulaşılabilir,
                // örneğin exe dosyasının bulunduğu klasör üzerinden: "C:\03_OOP\12_InterfacesVsAbstractClasses\bin\Debug\net6.0"
                // ".." ile "C:\03_OOP\12_InterfacesVsAbstractClasses\bin\Debug" klasörüne,
                // "../.." ile "C:\03_OOP\12_InterfacesVsAbstractClasses\bin" klasörüne,
                // "../../.." ile de "C:\03_OOP\12_InterfacesVsAbstractClasses" klasörüne ulaşılabilir,
                // örnek dosyamız "Dosyalar" klasöründe olduğundan "../../../Dosyalar/Öğrenciler.txt" yazmalıyız
            };



            // dosyadaki öğrenci bilgilerinin konsola başlarına sayı eklenmeden yazdırılması
            Console.WriteLine("Öğrenciler\n" + ogrenciDosya.OgrencileriGetir(false));



            // yeni öğrenci bilgisinin kullanıcıdan alınması ve dosyaya eklenmesi
            Console.WriteLine("\nYeni Öğrenci Girişi");
            Console.Write("Adı: ");
            string adi = Console.ReadLine();
            Console.Write("Soyadı: ");
            string soyadi = Console.ReadLine();
            Console.Write("Yaşı: ");
            string yasi = Console.ReadLine();

            // kullanıcıdan alınan öğrenci bilgisi üzerinden dosyaya eklenecek formatta öğrenci oluşturulması
            string yeniOgrenci = "Adı:" + adi + " - Soyadı:" + soyadi + " - Yaşı:" + yasi;

            ogrenciDosya.OgrenciEkle(yeniOgrenci);



            // dosyadaki öğrenci bilgilerinin konsola başlarına sayı eklenerek yazdırılması
            Console.WriteLine("\nÖğrenciler\n" + ogrenciDosya.OgrencileriGetir(true));



            // dosya adının konsola yazdırılması
            Console.WriteLine("\nDosya Adı: " + ogrenciDosya.DosyaAdiGetir());



            // dosya uzantısının konsola yazdırılması
            Console.WriteLine("Dosya Uzantısı: " + ogrenciDosya.DosyaUzantisiGetir());
        }
    }
}
