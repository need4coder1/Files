﻿using System.Globalization;

namespace _04_StaticClassesAndMethods
{
    /// <summary>
    /// String tipindeki veriler üzerinden işlemler gerçekleştirilebilen utility sınıfı.
    /// </summary>
    static class StringUtil
    {
        /// <summary>
        /// value ve default olarak true atanmış trim parametreleri üzerinden gönderilen string tipindeki value'nun null, "" veya " "
        /// değere sahip olup olmadığını kontrol eden method.
        /// </summary>
        /// <param name="value"></param>
        /// <param name="trim"></param>
        /// <returns>bool</returns>
        public static bool IsEmpty(string value, bool trim = true) // boş mu
        {
            //if (value == null) // 1. yöntem
            if (value is null) // 2. yöntem
                return true;

            if (trim) // eğer trim true ise
            {
                //if (value.Trim() == "") // 1. yöntem
                //if (value.Trim().Equals("") // 2. yöntem
                if (string.IsNullOrWhiteSpace(value)) // 3. yöntem (en uygun)
                    return true;
            }
            else // eğer trim false ise
            {
                //if (value == "") // 1. yöntem
                //if (value.Equals("")) // 2. yöntem
                if (string.IsNullOrEmpty(value)) // 3. yöntem (en uygun)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// value ve default olarak tr-TR atanmış culture (bölgesel ayar) input parametreleri üzerinden gönderilen string tipindeki value'nun
        /// sayısal olup olmadığını kontrol eden, ve number output parametresi üzerinden double dönüştürme işlemi başarılıysa 
        /// number output parametresini de dönen method.
        /// </summary>
        /// <param name="value"></param>
        /// <param name="culture"></param>
        /// <returns>bool</returns>
        public static bool IsNumeric(string value, out double number, string culture = "tr-TR") // sayısal mı
        {
            // TryParse parametreleri sırasıyla:
            // value: string değer,
            // NumberStyles.Number: dönüştürülmeye çalışılacak sayı stili,
            // new CultureInfo(culture): culture parametresine göre bölgesel ayar,
            // out number: TryParse methodu içerisinde dönüştürme işlemi başarılıysa dönüştürülen sayı olarak güncellenecek number referansı (adresi)
            return double.TryParse(value, NumberStyles.Number, new CultureInfo(culture), out number);
        }
    }
}
