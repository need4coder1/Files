﻿namespace _09_Inheritance
{
    class FutbolTakimi : Takim // sub (child) concrete (somut) class, concrete (somut) class'lar üzerinden obje new'lenebilir,
                                      // is-a relationship: FutbolTakimi bir Takim'dır (FutbolTakimi is a Takim)
    {
        #region Properties
        public string TeknikDirektorAdi { get; set; }
        public string KaleciAdi { get; set; }
        public string DefansOyuncuAdlari { get; set; }
        public string OrtaSahaOyuncuAdlari { get; set; }
        public string ForvetOyuncuAdlari { get; set; }
        public string OyunSistemi { get; set; }
        #endregion



        #region Behaviors
        public string KadroGetir()
        {
            return $"Teknik Direktör: {TeknikDirektorAdi}\nKaleci: {KaleciAdi}\n" +
                $"Defans Oyuncuları: {DefansOyuncuAdlari}\nOrta Saha Oyuncuları: {OrtaSahaOyuncuAdlari}\nForvet Oyuncuları: {ForvetOyuncuAdlari}";
        }
        #endregion
    }
}
