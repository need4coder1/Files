﻿namespace _09_Inheritance
{
    class BasketbolTakimi : Takim // sub (child) concrete (somut) class, concrete (somut) class'lar üzerinden obje new'lenebilir,
                                         // is-a relationship: BasketbolTakimi bir Takim'dır (BasketbolTakimi is a Takim)
    {
        #region Properties
        public string BasantrenorAdi { get; set; }
        public string GeriSahaOyuncuAdlari { get; set; }
        public string OnSahaOyuncuAdlari { get; set; }
        #endregion
    }
}
