﻿namespace _09_Inheritance.Demos.Elektronik.Models.Bases
{
    class ElektronikEsya // base (parent) concrete (somut) class
    {
        #region Properties
        public string Marka { get; set; }
        public string Model { get; set; }
        public string SeriNo { get; set; }
        public DateTime UretimTarihi { get; set; }
        #endregion
    }
}
