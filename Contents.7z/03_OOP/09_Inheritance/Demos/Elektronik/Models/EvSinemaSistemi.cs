﻿using _09_Inheritance.Demos.Elektronik.Models.Bases;

namespace _09_Inheritance.Demos.Elektronik.Models
{
    class EvSinemaSistemi : ElektronikEsya // sub (child) concrete (somut) class,
                                                  // is-a relationship: ev sinema sistemi bir elektronik eşyadır
    {
        #region Properties
        public byte HoparlorSayisi { get; set; }
        public short Guc { get; set; } // Watt
        #endregion
    }
}
