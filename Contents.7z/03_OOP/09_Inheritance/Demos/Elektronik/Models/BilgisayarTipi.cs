﻿namespace _09_Inheritance.Demos.Elektronik.Models
{
    enum BilgisayarTipi
    {
        Masaüstü,
        Dizüstü,
        Sunucu
    }
}
