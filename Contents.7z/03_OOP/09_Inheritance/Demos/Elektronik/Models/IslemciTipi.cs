﻿namespace _09_Inheritance.Demos.Elektronik.Models
{
    enum IslemciTipi
    {
        i9 = 9,
        i7 = 7,
        i5 = 5,
        i3 = 3
    }
}
