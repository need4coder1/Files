﻿using _09_Inheritance.Demos.Sekiller.Bases;

namespace _09_Inheritance.Demos.Sekiller
{
    class Dikucgen : KoseliSekil, IHesapla // Dikucgen bir KoseliSekil'dir ve IHesapla interface'ini implemente eder
    {
        public double AlanHesapla()
        {
            return Genislik * Yukseklik / 2;
        }

        public double CevreHesapla()
        {
            double hipotenus = Math.Sqrt(Math.Pow(Genislik, 2) + Math.Pow(Yukseklik, 2));
            return hipotenus + Genislik + Yukseklik;
        }
    }
}
