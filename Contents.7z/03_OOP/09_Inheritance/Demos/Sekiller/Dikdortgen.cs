﻿using _09_Inheritance.Demos.Sekiller.Bases;

namespace _09_Inheritance.Demos.Sekiller
{
    class Dikdortgen : KoseliSekil, IHesapla // Dikdortgen bir KoseliSekil'dir ve IHesapla interface'ini implemente eder
    {
        public double AlanHesapla()
        {
            return Genislik * Yukseklik;
        }

        public double CevreHesapla()
        {
            return 2 * (Genislik + Yukseklik);
        }
    }
}
