﻿using _09_Inheritance.Demos.Sekiller.Bases;

namespace _09_Inheritance.Demos.Sekiller
{
    public class SekillerDemo
    {
        public static void Calistir()
        {
            Daire daire1 = new Daire() // Daire tipinde instance (obje) oluşturma (initialization)
            {
                Yaricap = 5,
                PiUcMu = false
            };

            Console.WriteLine("1. dairenin çevresi: " + daire1.CevreHesapla());
            Console.WriteLine("1. dairenin alanı: " + daire1.AlanHesapla());



            Daire daire2 = new Daire()
            {
                Yaricap = 10
            }; // PiUcMu özelliği atanmadığından YuvarlakSekil class'ındaki (sınıfındaki) default (varsayılan) atanan değer yani true atanacaktır

            Console.WriteLine($"2. dairenin çevresi: {daire2.CevreHesapla()}");
            Console.WriteLine($"2. dairenin alanı: {daire2.AlanHesapla()}");



            KoseliSekil koseliSekil1 = new Dikdortgen() // KoseliSekil tipindeki değişken Dikdortgen tipindeki objeyi refere ediyor
            {
                Genislik = 4,
                Yukseklik = 3
            };

            // KoseliSekil sınıfının içerisinde alan ve çevre hesapla methodları olmadığından ve bu methodlar Dikdortgen sınıfında olduğundan
            // bu methodları çağırabilmek için (koseliSekil1 as Dikdortgen) veya ((Dikdortgen)koseliSekil1) ile
            // KoseliSekil tipindeki değişkeni Dikdortgen'e cast etmemiz gerek
            Console.WriteLine("1. dikdörtgenin çevresi: " + (koseliSekil1 as Dikdortgen).CevreHesapla()); 
            Console.WriteLine("1. dikdörtgenin alanı: " + ((Dikdortgen)koseliSekil1).AlanHesapla());



            Dikucgen dikucgen = new Dikucgen() // Dikucgen tipindeki değişken Dikucgen tipindeki objeyi refere ediyor
            {
                Genislik = 12,
                Yukseklik = 9
            };

            Console.WriteLine("2. diküçgenin çevresi: " + dikucgen.CevreHesapla());
            Console.WriteLine("2. diküçgenin alanı: " + dikucgen.AlanHesapla());
        }
    }
}
