﻿namespace _09_Inheritance.Demos.Sekiller.Bases
{
    class YuvarlakSekil
    {
        public double Yaricap { get; set; }
        public bool PiUcMu { get; set; } = true;
    }
}
