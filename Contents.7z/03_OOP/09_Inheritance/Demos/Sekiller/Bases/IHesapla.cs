﻿namespace _09_Inheritance.Demos.Sekiller.Bases
{
    interface IHesapla
    {
        // interface'deki özellik ve methodlar başlarına public yazılarak da tanımlanabilir
        public double AlanHesapla();
        public double CevreHesapla();
    }
}
