﻿namespace _09_Inheritance.Demos.Sekiller.Bases
{
    class KoseliSekil
    {
        public double Genislik { get; set; }
        public double Yukseklik { get; set; }
    }
}
