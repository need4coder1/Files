﻿namespace _09_Inheritance
{
    //public class Takim : Object 
    //public class Takim : object
    // C# programlama dilinde tüm class'lar Object class'ından miras aldığı için üsttekileri yazmaya gerek yoktur
    class Takim // base (parent) concrete (somut) class, concrete (somut) class'lar üzerinden obje new'lenebilir
    {
        #region Properties
        public string Adi { get; set; }
        public short KurulusYili { get; set; }
        public string Sehir { get; set; }
        #endregion



        #region Behaviors
        public string BilgiGetir()
        {
            return $"Takım: {Adi}\nKuruluş Yılı: {KurulusYili}";
        }
        #endregion
    }
}
