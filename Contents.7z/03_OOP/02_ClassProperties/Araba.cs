﻿namespace _02_ClassProperties
{
    class Araba // içerisinde araba verilerini tutan sınıf.
    {
        public string Marka { get; set; } // property, özellik, obje üzerinden ulaşılacağı için genellikle public yapılır.
        public string Model { get; set; } // property
        public byte KapiSayisi { get; set; } = 4; // property, istenirse özelliklere ilk değer ataması yapılabilir, obje üzerinden atama yapılmazsa bu değer kullanılır.
        public short BeygirGucu { get; set; } // property
        public double MotorHacmi { get; set; } // property
        public DateTime TrafigeCikisTarihi { get; set; } // property
        public ArabaTipi Turu { get; set; } = ArabaTipi.Binek; // property
    }
}
