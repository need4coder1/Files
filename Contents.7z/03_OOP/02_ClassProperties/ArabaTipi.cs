﻿namespace _02_ClassProperties
{
    enum ArabaTipi
    {
        Binek = 1,
        Ticari = 2
    }
}
