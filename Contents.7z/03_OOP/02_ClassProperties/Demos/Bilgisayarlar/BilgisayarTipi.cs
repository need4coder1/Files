﻿namespace _02_ClassProperties.Demos.Bilgisayarlar
{
    public enum BilgisayarTipi
    {
        Masaüstü,
        Dizüstü,
        Sunucu
    }
}
