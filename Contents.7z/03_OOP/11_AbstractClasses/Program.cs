﻿using _11_AbstractClasses._1_ProductAndStore;
using _11_AbstractClasses._2_Dersler;
using _11_AbstractClasses.Demos.Sekiller;
using System.Globalization;

namespace _11_AbstractClasses
{
    internal class Program
    {
        // Abstract Class'lar (soyut sınıflar) kalıtımda base (parent) class'ın başına abstract yazılarak bu sınıfın soyutlaştırılması ile
        // bu sınıf üzerinden obje new'lenmesinin engellenmesini sağlar.
        // Kalıtımda genelde base class'lar üzerinden obje new'lenmez çünkü esas new'lenerek kullanılacak objeler sub class tipinde objelerdir,
        // dolayısıyla base class initialize edilmeyecek şekilde soyutlaştırılarak sub class'lar için bir altyapı olarak hazırlanır.
        // Base class'ların, özellikle abstract olanların, adlarının sonuna Base kelimesi eklenir, örneğin RepoBase, KayitBase vb.



        static void Main(string[] args)
        {
            #region Abstract Class'lar (Product and Store)
            ProductAndStoreDemo.Calistir();
            #endregion



            #region Abstract Class'larda Virtual ve Abstract Kullanımı (Dersler)
            DerslerDemo.Calistir();
            #endregion



            #region Demos
            SekillerDemo.Calistir();
            #endregion
        }
    }
}