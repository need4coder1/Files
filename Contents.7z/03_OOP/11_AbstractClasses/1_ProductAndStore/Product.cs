﻿using _11_AbstractClasses._1_ProductAndStore.Bases;

namespace _11_AbstractClasses._1_ProductAndStore
{
    /// <summary>
    /// Veritabanında yönetilecek ürünler için RecordBase'den miras alan ve içerisinde ürün özellikleri bulunan somut sub class.
    /// </summary>
    class Product : RecordBase // Product (ürün) bir RecordBase'dir (is-a relationship)
    {
        // Id ve Guid özellikleri RecordBase'den miras alındığından bu sınıf üzerinden kullanılabilir

        public string Name { get; set; } // ürün adı özelliği
        public double UnitPrice { get; set; } // Dolar cinsinden ürün birim fiyatı özelliği
        public int StockAmount { get; set; } // ürün stok miktarı özelliği
    }
}
