﻿using _11_AbstractClasses._1_ProductAndStore.Bases;

namespace _11_AbstractClasses._1_ProductAndStore
{
    class Store : RecordBase // Store (mağaza) bir RecordBase'dir (is-a relationship)
    {
        // Id ve Guid özellikleri RecordBase'den miras alındığından bu sınıf üzerinden kullanılabilir

        public string Name { get; set; } // mağaza adı özelliği
        public string Country { get; set; } // mağazanın ülkesi özelliği
        public string City { get; set; } // mağazanın ili özelliği
    }
}
