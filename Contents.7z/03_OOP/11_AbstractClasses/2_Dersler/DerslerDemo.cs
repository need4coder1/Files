﻿namespace _11_AbstractClasses._2_Dersler
{
    public class DerslerDemo
    {
        public static void Calistir()
        {
            YazilimDersi yazilimDersi = new YazilimDersi() // yazilimDersi objesi initialization
            {
                Id = 101, // DersBase'den miras alınan özellik
                Adi = "C# Programlama Dili", // DersBase'den miras alınan özellik
                Sinav1Notu = 90, // DersBase'den miras alınan özellik
                Sinav2Notu = 70, // DersBase'den miras alınan özellik
                SonSinavNotu = 80 // YazilimDersi özelliği
            };

            string yazilimDersiKodu = yazilimDersi.KodGetir(); // YazilimDersi'nde ezilen (override) DersBase'deki soyut (abstract) method tanımı, YZL-101 döner
            byte yazilimDersiMaksimumNotu = yazilimDersi.MaksimumNotGetir(); // DersBase'deki sanal (virtual) method, 100 döner
            double yazilimDersiNotu = yazilimDersi.DersNotuHesapla(); // YazilimDersi'nde ezilen (override) DersBase'deki sanal (virtual) method

            // ders bilgilerini konsola yazdırma
            Console.WriteLine($"\nDers Kodu: {yazilimDersiKodu}\nDers Adı: {yazilimDersi.Adi}\n" +
                $"Ders Notu: {yazilimDersiMaksimumNotu} üzerinden {yazilimDersiNotu}");



            MuzikDersi muzikDersi = new MuzikDersi() // muzikDersi objesi initialization
            {
                Id = 201, // DersBase'den miras alınan özellik
                Adi = "Armoni", // DersBase'den miras alınan özellik
                Sinav1Notu = 3, // DersBase'den miras alınan özellik
                Sinav2Notu = 7 // DersBase'den miras alınan özellik
            };

            // ders bilgilerini konsola yazdırma, KodGetir methodu MZK-201, MaksimumNotGetir methodu ise 10 döner
            Console.WriteLine($"\nDers Kodu: {muzikDersi.KodGetir()}\nDers Adı: {muzikDersi.Adi}\n" +
                $"Ders Notu: {muzikDersi.MaksimumNotGetir()} üzerinden {muzikDersi.DersNotuHesapla()}");
        }
    }
}
