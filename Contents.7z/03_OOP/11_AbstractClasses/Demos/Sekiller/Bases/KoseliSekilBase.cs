﻿namespace _11_AbstractClasses.Demos.Sekiller.Bases
{
    abstract class KoseliSekilBase
    {
        public double Genislik { get; set; }
        public double Yukseklik { get; set; }

        public abstract double AlanHesapla();
        public abstract double CevreHesapla();
    }
}
