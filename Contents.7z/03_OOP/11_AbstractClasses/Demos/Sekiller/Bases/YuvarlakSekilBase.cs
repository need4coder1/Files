﻿namespace _11_AbstractClasses.Demos.Sekiller.Bases
{
    abstract class YuvarlakSekilBase
    {
        public double Yaricap { get; set; }
        public bool PiUcMu { get; set; } = true; // abstract class'larda property'lere ilk değer ataması yapılabilir

        public abstract double AlanHesapla();
        public abstract double CevreHesapla();
    }
}
