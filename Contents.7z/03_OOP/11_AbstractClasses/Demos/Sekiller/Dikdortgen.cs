﻿using _11_AbstractClasses.Demos.Sekiller.Bases;

namespace _11_AbstractClasses.Demos.Sekiller
{
    /// <summary>
    /// KoseliSekilBase abstract (soyut) class'ından miras alan concrete (somut) class.
    /// </summary>
    class Dikdortgen : KoseliSekilBase // Dikdortgen bir KoseliSekilBase'dir şeklinde de okunabilir
    {
        public override double AlanHesapla() // methodun ezilerek implementasyonu
        {
            return Genislik * Yukseklik;
        }

        public override double CevreHesapla() // methodun ezilerek implementasyonu
        {
            return 2 * (Genislik + Yukseklik);
        }
    }
}
