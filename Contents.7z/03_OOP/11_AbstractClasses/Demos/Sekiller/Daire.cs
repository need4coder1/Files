﻿using _11_AbstractClasses.Demos.Sekiller.Bases;

namespace _11_AbstractClasses.Demos.Sekiller
{
    /// <summary>
    /// YuvarlakSekilBase abstract (soyut) class'ından miras alan concrete (somut) class.
    /// </summary>
    class Daire : YuvarlakSekilBase // Daire bir YuvarlakSekilBase'dir şeklinde de okunabilir
    {
        public override double AlanHesapla() // methodun ezilerek implementasyonu
        {
            return PiUcMu ? 3 * Math.Pow(Yaricap, 2) : Math.PI * Math.Pow(Yaricap, 2);
        }

        public override double CevreHesapla() // methodun ezilerek implementasyonu
        {
            return PiUcMu ? 2 * 3 * Yaricap : 2 * Math.PI * Yaricap;
        }
    }
}
