﻿namespace _21_ConstructorChaining.Demos.DosyaIslemleri.Models
{
    /// <summary>
    /// Öğrenci bilgileri için somut model sınıfı.
    /// </summary>
    public class Ogrenci
    {
        #region Özellikler
        public string Adi { get; set; }
        public string Soyadi { get; set; }
        public int Yasi { get; set; }
        #endregion
    }
}
