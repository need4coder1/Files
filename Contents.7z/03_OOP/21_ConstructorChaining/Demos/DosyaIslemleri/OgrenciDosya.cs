﻿using _21_ConstructorChaining.Demos.DosyaIslemleri.Bases;

namespace _21_ConstructorChaining.Demos.DosyaIslemleri
{
    class OgrenciDosya : OgrenciDosyaBase // OgrenciDosyaBase sınıfından miras alan OgrenciDosya sınıfı,
                                          // OgrenciDosya bir OgrenciDosyaBase'dir şeklinde de okunabilir (is-a relationship).
    {
        public OgrenciDosya(string dosyaYolu) : base(dosyaYolu) // Constructor Chaining: OgrenciDosya (sub) tipinde obje new'lenirken
                                                                // gönderilen dosyaYolu parametresi OgrenciDosyaBase (base) sınıfının
                                                                // constructor'ına gönderilir ki base sınıftaki methodlarda kullanılabilsin.
        {
        }
    }
}
